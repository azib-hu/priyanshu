# Portfolio Update — VARI / ART case study

- Removed the custom glowing cursor so the cyan cursor dot no longer appears over artwork.
- Kept the VARI / ART homepage banner unchanged.
- VARI / ART `View Case Study` now opens a dedicated dark case-study presentation instead of simply repeating the homepage banner.
- The case study uses the clean VARI / ART identity board as its hero visual, followed by overview, role, concept breakdown, process and deliverables.
- Fixed case-study card contrast so text is readable on the dark theme.
- Typography / Heyzine links and the rest of the portfolio behavior are preserved.
