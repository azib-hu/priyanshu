import type { ServiceItem } from '../types';

export const servicesData: ServiceItem[] = [
  {
    name: "Graphic Design",
    description: "Campaign graphics, visual layouts and production-ready artwork built for real communication needs.",
  },
  {
    name: "Logo & Branding",
    description: "Logo systems, colour direction and practical identity assets developed from concept to final artwork.",
  },
  {
    name: "Social Media Design",
    description: "Social posts, stories, promotional creatives and campaign graphics with clear hierarchy.",
  },
  {
    name: "Poster & Banner Design",
    description: "Posters, banners and promotional graphics designed to stay legible from screen to large-format print.",
  },
  {
    name: "Print Design",
    description: "Brochures, stationery, catalogues and print-ready files with attention to prepress and production.",
  },
  {
    name: "Photo Editing",
    description: "Retouching, compositing, colour correction and image cleanup for finished campaign and print work.",
  },
];
