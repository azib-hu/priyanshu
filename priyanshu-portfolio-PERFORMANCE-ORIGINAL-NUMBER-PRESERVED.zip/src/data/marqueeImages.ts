export const marqueeRow1 = [
  "/assets/projects/vari-art-banner.webp",
  "/assets/projects/tote-bag-mockup-set.webp",
  "/assets/projects/logo-design-mockup.webp",
];

export const marqueeRow2 = [
  "/assets/projects/typography-showcase.webp",
  "/assets/projects/brochure-trifold-mockup.webp",
  "/assets/projects/retail-dangler.webp",
];
