import type { ProjectItem } from '../types';

const p = (name: string) => `/assets/projects/${name}`;

export const projectsData: ProjectItem[] = [
  // ========================= SELECTED WORK =========================
  {
    id: 'vari-art',
    portfolioSection: 'selected',
    number: '01',
    category: 'Conceptual Identity',
    filterCategory: 'branding',
    tags: ['branding', 'print'],
    title: 'VARI / ART',
    shortDescription: 'A conceptual identity built around one word with two readings: VARI (variation) and ART (creation).',
    tools: ['Adobe Illustrator'],
    col1Image1: p('vari-art.png'),
    showcaseImage: p('vari-art-banner.png'),
    col1Image2: p('vari-art.png'),
    col2Image: p('vari-art.png'),
    caseStudy: {
      overview: 'VARI / ART is a conceptual identity built around one word with two readings. The same letterforms are reinterpreted so VARI reads as variation while ART reads as creation.',
      role: 'Graphic Designer — concept, letterform construction and identity presentation.',
      process: ['Start with one word', 'Build the shared letterforms', 'Create the second reading', 'Refine spacing and visual rhythm', 'Present the identity as a flexible system'],
      deliverables: ['Conceptual Logo', 'Letterform System', 'Identity Presentation'],
      images: [p('vari-art.png')]
    }
  },
  {
    id: 'logo-design',
    portfolioSection: 'selected',
    number: '02',
    category: 'Brand Identity',
    filterCategory: 'branding',
    tags: ['branding', 'print'],
    title: 'Logo Design',
    shortDescription: 'Logo identity exploration with a distinctive mark, colour system and print-oriented brand presentation.',
    tools: ['Adobe Illustrator', 'Adobe Photoshop'],
    col1Image1: p('logo-design-mockup.png'),
    col1Image2: p('logo-palette.png'),
    col2Image: p('logo-design-identity.png'),
    showcaseImage: p('logo-design-mockup.png'),
    caseStudy: {
      overview: 'A brand identity exploration built around a distinctive Devanagari-inspired mark, a brush-and-paint visual language, and a compact colour system for creative production work.',
      role: 'Graphic Designer — logo concept, vector construction, colour direction and identity presentation.',
      process: ['Concept exploration', 'Letterform and symbol construction', 'Brush and paint detailing', 'Colour system', 'Identity presentation'],
      deliverables: ['Primary Logo', 'Colour Palette', 'Tagline', 'Identity Presentation', 'Brand Applications'],
      images: [p('logo-design-mockup.png'), p('logo-design-identity.png'), p('logo-palette.png')]
    }
  },
  {
    id: 'logo-redesign',
    portfolioSection: 'selected',
    number: '03',
    category: 'Logo Redesign',
    filterCategory: 'branding',
    tags: ['branding'],
    title: 'Logo Redesign — Conceptual Rebrand',
    shortDescription: 'An unofficial redesign exercise exploring a new visual direction for an existing mark.',
    tools: ['Adobe Illustrator'],
    col1Image1: p('logo-redesign-mockup-final.png'),
    col1Image2: p('logo-redesign-final.png'),
    col2Image: p('logo-redesign-final.png'),
    caseStudy: {
      overview: 'A conceptual / unofficial logo redesign exercise. The project is presented as a design exploration, not as commissioned brand work.',
      role: 'Graphic Designer',
      process: ['Original mark review', 'Redesign exploration', 'Vector refinement', 'Presentation system'],
      deliverables: ['Logo Redesign', 'Concept Presentation'],
      images: [p('logo-redesign-mockup-final.png'), p('logo-redesign-final.png')]
    }
  },
  {
    id: 'my-mother-branding',
    portfolioSection: 'selected',
    number: '04',
    category: 'Personal Brand Identity',
    filterCategory: 'branding',
    tags: ['branding', 'print'],
    title: 'Branding — My Mother',
    shortDescription: 'A personal identity project translating family, Garhwal roots, care and strength into a visual system.',
    tools: ['Adobe Illustrator', 'Adobe Photoshop'],
    col1Image1: p('mother-brand-1.jpg'),
    col1Image2: p('mother-brand-3.jpg'),
    col2Image: p('mother-brand-5.jpg'),
    caseStudy: {
      overview: 'Personal brand identity for Snehlata from Pauri Garhwal, Uttarakhand. The identity explores caring, family-first values, strength, calmness and nurturing through a heart-and-mountain logo concept.',
      role: 'Graphic Designer',
      process: ['Brand values', 'Logo concept exploration', 'Symbol construction', 'Colour and packaging system'],
      deliverables: ['Logo Concept', 'Colour Scheme', 'Tagline', 'Packaging Mockups'],
      images: [p('mother-brand-1.jpg'), p('mother-brand-3.jpg'), p('mother-brand-5.jpg'), p('mother-brand-6.jpg'), p('mother-brand-8.jpg')]
    }
  },
  {
    id: 'architectural-digest',
    portfolioSection: 'selected',
    number: '05',
    category: 'Editorial / Publication',
    filterCategory: 'editorial',
    tags: ['editorial', 'print'],
    title: 'Architectural Digest — Mountain Homes',
    liveUrl: 'https://heyzine.com/flip-book/8bef9d29a2.html#page/1',
    imageLinkUrl: 'https://heyzine.com/flip-book/8bef9d29a2.html#page/1',
    shortDescription: 'A 13-page conceptual editorial magazine exploring Himalayan mountain homes, stone, wood, Likhai and woven textiles.',
    tools: ['Adobe InDesign', 'Adobe Photoshop'],
    col1Image1: p('magazine-2.jpg'),
    col1Image2: p('magazine-4.jpg'),
    col2Image: p('magazine-6.jpg'),
    caseStudy: {
      overview: 'A conceptual editorial publication built around Himalayan architecture and domestic craft. The issue moves through Stone, Wood & Likhai, and Woolen Narratives.',
      role: 'Editorial Designer',
      process: ['Editorial structure', 'Image and text hierarchy', 'Section opener design', 'Multi-page layout'],
      deliverables: ['Magazine Cover', 'Contents', 'Editorial Spreads', 'Closing Spread'],
      images: [p('magazine-2.jpg'), p('magazine-4.jpg'), p('magazine-6.jpg'), p('magazine-7.jpg'), p('magazine-9.jpg'), p('magazine-12.jpg'), p('magazine-13.jpg')]
    }
  },
  {
    id: 'typography-study',
    portfolioSection: 'selected',
    number: '06',
    category: 'Editorial / Typography',
    filterCategory: 'editorial',
    tags: ['editorial', 'print'],
    title: 'Typography — A Visual Study',
    liveUrl: 'https://heyzine.com/flip-book/e8f633412d.html',
    showcaseImage: p('typography-showcase.png'),
    imageLinkUrl: 'https://heyzine.com/flip-book/e8f633412d.html',
    shortDescription: 'A multi-page editorial study covering readability, mood, brand identity and the history of typography.',
    tools: ['Adobe InDesign', 'Adobe Illustrator'],
    col1Image1: p('typography-editorial-preview.png'),
    col1Image2: p('type-specimen-poster.jpg'),
    col2Image: p('typography-study.png'),
    caseStudy: {
      overview: 'A typography publication exploring why typography matters and tracing major developments from Gutenberg and serif type through modernist sans-serifs and variable digital fonts.',
      role: 'Editorial Designer',
      process: ['Information hierarchy', 'Typography selection', 'Editorial composition', 'Page system'],
      deliverables: ['Typography Publication', 'Type Study Poster'],
      images: [p('typography-study.png'), p('type-specimen-poster.jpg')]
    }
  },
  {
    id: 'brochure-print',
    portfolioSection: 'selected',
    number: '07',
    category: 'Brochure / Print',
    filterCategory: 'print',
    tags: ['print'],
    title: 'Brochure Design',
    shortDescription: 'Print collateral exploration focused on clear information hierarchy and physical presentation.',
    tools: ['Adobe Illustrator', 'Adobe InDesign'],
    col1Image1: p('brochure-trifold-mockup.png'),
    col1Image2: p('brochure-trifold-mockup.png'),
    col2Image: p('brochure-trifold-mockup.png'),
    showcaseImage: p('brochure-trifold-mockup.png'),
    caseStudy: {
      overview: 'A Uttarakhand tourism tri-fold brochure focused on destination information, attractions, adventure activities, culture, food and practical travel planning.',
      role: 'Graphic Designer — brochure layout, information hierarchy and print presentation.',
      process: ['Information structure', 'Editorial layout', 'Image and typography hierarchy', 'Tri-fold print presentation'],
      deliverables: ['Tri-fold Brochure', 'Print Presentation'],
      images: [p('brochure-trifold-mockup.png')]
    }
  },
  {
    id: 'tote-bag',
    portfolioSection: 'selected',
    number: '08',
    category: 'Merch / Physical Application',
    filterCategory: 'applications',
    tags: ['applications', 'print'],
    title: 'Tote Bag Design',
    shortDescription: 'Three original tote bag graphics presented as physical applications: Dreamer, Meow and Imagine.',
    tools: ['Adobe Illustrator', 'Adobe Photoshop'],
    col1Image1: p('tote-bag-mockup-set.png'),
    col1Image2: p('tote-dreamer-mockup.png'),
    col2Image: p('tote-meow-mockup.png'),
    caseStudy: {
      overview: 'A collection of three tote bag graphics exploring illustration, typography and playful visual applications.',
      role: 'Graphic Designer',
      process: ['Graphic concept', 'Illustration / typography', 'Print placement', 'Physical mockup'],
      deliverables: ['Dreamer Tote', 'Meow Tote', 'Imagine Tote'],
      images: [p('tote-bag-mockup-set.png'), p('tote-dreamer-mockup.png'), p('tote-meow-mockup.png'), p('tote-imagine-mockup.png')]
    }
  },
  {
    id: 'pos-dangler',
    portfolioSection: 'selected',
    number: '09',
    category: 'Retail Graphic',
    filterCategory: 'applications',
    tags: ['applications', 'print'],
    title: 'Retail Graphic',
    shortDescription: 'Point-of-sale display design prepared for physical retail presentation.',
    tools: ['Adobe Illustrator', 'Adobe Photoshop'],
    col1Image1: p('retail-dangler.jpg'),
    col1Image2: p('retail-wobbler.jpg'),
    col2Image: p('retail-dangler.jpg'),
    caseStudy: {
      overview: 'A retail point-of-sale design study showing how flat artwork translates into physical hanging and shelf communication.',
      role: 'Graphic Designer',
      process: ['POS layout', 'Print artwork', 'Physical presentation'],
      deliverables: ['Dangler', 'Wobbler', 'Retail Graphic Artwork'],
      images: [p('retail-dangler.jpg'), p('retail-wobbler.jpg')]
    }
  },

  // ========================= SMALLER / EXPERIMENTAL =========================
  {
    id: 'graphic-poster-experiments',
    portfolioSection: 'smaller',
    number: 'S02',
    category: 'Graphic / Poster Experiments',
    filterCategory: 'posters',
    tags: ['posters', 'typography', 'advertising'],
    title: 'Graphic / Poster Experiments',
    shortDescription: 'A compact collection of poster and graphic experiments spanning awareness, local advertising, typography and campaign visuals.',
    tools: ['Adobe Photoshop', 'Adobe Illustrator'],
    col1Image1: p('poster-no-pfp.png'),
    col1Image2: p('ramu-cobbler-new.png'),
    col2Image: p('bank-gothic-poster-new.png'),
    caseStudy: {
      overview: 'A consolidated collection of graphic and poster experiments featuring an anti-addiction awareness poster, Ramu Cobbler local advertising, and a Bank Gothic typography study.',
      role: 'Graphic Designer',
      deliverables: ['Awareness Poster', 'Local Advertising Poster', 'Typography Poster'],
      images: [
        p('poster-no-pfp.png'),
        p('anti-addiction.png'),
        p('ramu-cobbler-new.png'),
        p('bank-gothic-poster-new.png')
      ]
    }
  },
  {
    id: 'visual-experiments',
    portfolioSection: 'smaller',
    number: 'S03',
    category: 'Conceptual / Visual Experiments',
    filterCategory: 'experimental',
    tags: ['experimental', 'photo-editing'],
    title: 'Conceptual / Visual Experiments',
    shortDescription: 'A collection of surreal photo-manipulation experiments exploring visual metaphor and unexpected combinations.',
    tools: ['Adobe Photoshop'],
    col1Image1: p('conceptual-experiments-preview.jpg'),
    col1Image2: p('artboard-5.png'),
    col2Image: p('artboard-4.png'),
    caseStudy: {
      overview: 'A collection of five visual experiments exploring surreal compositions, visual metaphor, photo manipulation and unexpected object combinations.',
      role: 'Graphic Designer',
      deliverables: ['Conceptual Compositions', 'Photo Manipulation', 'Visual Experiments'],
      images: [
        p('artboard-5.png'),
        p('artboard-4.png'),
        p('artboard-3.png'),
        p('artboard-1.png'),
        p('artboard-2.png')
      ]
    }
  },



];
