import { FixedSocialBar } from './components/common/FixedSocialBar';
import { HeroSection } from './components/sections/HeroSection';
import { MarqueeSection } from './components/sections/MarqueeSection';
import { AboutSection } from './components/sections/AboutSection';
import { ToolsSection } from './components/sections/ToolsSection';
import { ServicesSection } from './components/sections/ServicesSection';
import { ProjectsSection } from './components/sections/ProjectsSection';
import { JourneySection } from './components/sections/JourneySection';
import { ContactSection } from './components/sections/ContactSection';
import { CustomCursor } from './components/common/CustomCursor';

function HomePage() {
  return (
    <main
      className="bg-transparent text-[#121212] min-h-screen w-full relative"
      style={{ overflowX: 'clip' }}
    >
      <HeroSection />
      <MarqueeSection />
      <AboutSection />
      <ToolsSection />
      <ServicesSection />
      <JourneySection />
      <ContactSection />
    </main>
  );
}

function App() {
  const isProjectsPage = window.location.pathname.replace(/\/$/, '') === '/projects';

  return (
    <>
      <CustomCursor />
      <FixedSocialBar />
      {isProjectsPage ? <ProjectsSection standalone /> : <HomePage />}
    </>
  );
}

export default App;
