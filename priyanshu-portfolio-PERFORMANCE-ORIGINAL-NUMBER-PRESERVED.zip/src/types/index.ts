export type ProjectFilterCategory =
  | 'all'
  | 'branding'
  | 'editorial'
  | 'social-media'
  | 'advertising'
  | 'applications'
  | 'posters'
  | 'print'
  | 'photo-editing'
  | 'experimental'
  | 'typography';

export interface ProjectCaseStudy {
  overview?: string;
  role?: string;
  process?: string[];
  toolsUsed?: string[];
  deliverables?: string[];
  images?: string[];
}

export type PortfolioSection = 'selected' | 'smaller';

export interface ProjectItem {
  id: string;
  portfolioSection: PortfolioSection;
  number: string;
  category: string;
  filterCategory: ProjectFilterCategory;
  tags?: ProjectFilterCategory[];
  title: string;
  shortDescription?: string;
  tools?: string[];
  liveUrl?: string;
  showcaseImage?: string;
  imageLinkUrl?: string;
  col1Image1: string;
  col1Image2: string;
  col2Image: string;
  caseStudy?: ProjectCaseStudy;
}

export interface ServiceItem {
  name: string;
  description: string;
}

