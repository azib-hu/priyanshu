import React from 'react';
import { motion } from 'framer-motion';

interface ContactButtonProps {
  className?: string;
  onClick?: (e: React.MouseEvent<HTMLAnchorElement>) => void;
  href?: string;
  label?: string;
}

export const ContactButton: React.FC<ContactButtonProps> = ({
  className = '',
  onClick,
  href = 'https://wa.me/919627616226',
  label = 'Contact Me',
}) => {
  return (
    <motion.a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      onClick={onClick}
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.97 }}
      transition={{ duration: 0.2 }}
      className={`rounded-full text-[#F1EFEA] font-medium uppercase tracking-widest cursor-pointer inline-flex items-center justify-center select-none px-5 py-2.5 sm:px-10 sm:py-3.5 md:px-12 md:py-4 text-xs sm:text-sm md:text-base transition-all duration-300 no-underline ${className}`}
      style={{
        background: '#D8D000',
        boxShadow: '0 8px 24px rgba(25, 167, 216, 0.18)',
        outline: '1px solid rgba(27, 127, 155, 0.35)',
        outlineOffset: '-3px',
      }}
    >
      {label}
    </motion.a>
  );
};
