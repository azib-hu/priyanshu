import React, { useEffect, useRef, useState } from 'react';
import { motion, useMotionValue, useSpring } from 'framer-motion';

type TrailParticle = { id: number; x: number; y: number; size: number; delay: number };
type ClickBurst = { id: number; x: number; y: number };

export const CustomCursor: React.FC = () => {
  const [enabled, setEnabled] = useState(false);
  const [visible, setVisible] = useState(false);
  const [hovered, setHovered] = useState(false);
  const [trail, setTrail] = useState<TrailParticle[]>([]);
  const [clickBursts, setClickBursts] = useState<ClickBurst[]>([]);
  const trailId = useRef(0);
  const clickId = useRef(0);
  const lastTrail = useRef(0);
  const lastMouse = useRef({ x: -100, y: -100 });
  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const sx = useSpring(x, { damping: 26, stiffness: 420, mass: 0.35 });
  const sy = useSpring(y, { damping: 26, stiffness: 420, mass: 0.35 });

  useEffect(() => {
    const fine = window.matchMedia('(pointer: fine)');
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setEnabled(fine.matches && !reduced.matches);
    update();
    fine.addEventListener?.('change', update);
    reduced.addEventListener?.('change', update);

    const move = (e: MouseEvent) => {
      x.set(e.clientX);
      y.set(e.clientY);
      setVisible(true);

      const target = e.target as HTMLElement | null;
      const isInteractive = Boolean(target?.closest('a,button,[role="button"],.cursor-pointer,[data-interactive="true"]'));
      setHovered(isInteractive);

      // The brush tip is the pointer. Keep the magical particles around the
      // visible painted tail (down/right from the tip), never on the tip itself.
      const now = performance.now();
      if (now - lastTrail.current > 22) {
        lastTrail.current = now;
        const dx = e.clientX - lastMouse.current.x;
        const dy = e.clientY - lastMouse.current.y;
        const distance = Math.max(1, Math.hypot(dx, dy));

        // Brush artwork points from the top-left tip toward its cyan tail.
        const tailX = 0.68;
        const tailY = 0.73;
        const id = ++trailId.current;
        const tailDistance = 32 + Math.random() * 58;
        const movementBackX = distance > 1 ? -(dx / distance) * Math.min(18, distance * 0.45) : 0;
        const movementBackY = distance > 1 ? -(dy / distance) * Math.min(18, distance * 0.45) : 0;
        const particle = {
          id,
          x: e.clientX + tailX * tailDistance + movementBackX + (Math.random() - 0.5) * 18,
          y: e.clientY + tailY * tailDistance + movementBackY + (Math.random() - 0.5) * 18,
          size: 1.8 + Math.random() * 4.8,
          delay: Math.random() * 0.12,
        };
        setTrail(prev => [...prev.slice(-29), particle]);
        window.setTimeout(() => setTrail(prev => prev.filter(item => item.id !== id)), 820);
      }
      lastMouse.current = { x: e.clientX, y: e.clientY };
    };

    const click = (e: MouseEvent) => {
      const id = ++clickId.current;
      setClickBursts(prev => [...prev.slice(-2), { id, x: e.clientX, y: e.clientY }]);
      window.setTimeout(() => setClickBursts(prev => prev.filter(item => item.id !== id)), 520);
    };

    const leave = () => setVisible(false);
    window.addEventListener('mousemove', move, { passive: true });
    window.addEventListener('mousedown', click, { passive: true });
    document.addEventListener('mouseleave', leave);

    return () => {
      fine.removeEventListener?.('change', update);
      reduced.removeEventListener?.('change', update);
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mousedown', click);
      document.removeEventListener('mouseleave', leave);
    };
  }, [x, y]);

  if (!enabled) return null;

  return (
    <>
      {trail.map((particle) => (
        <motion.span
          key={particle.id}
          className="fixed z-[2147483646] pointer-events-none rounded-full bg-[#D8D000] shadow-[0_0_9px_rgba(25,167,216,.9)]"
          style={{
            left: particle.x,
            top: particle.y,
            width: particle.size,
            height: particle.size,
            translateX: '-50%',
            translateY: '-50%',
          }}
          initial={{ opacity: 0, scale: 0.35 }}
          animate={{ opacity: [0, 0.9, 0], scale: [0.35, 1.25, 0.15], y: [0, -7, -15] }}
          transition={{ duration: 0.72, delay: particle.delay, ease: 'easeOut' }}
        />
      ))}

      {clickBursts.map((burst) => (
        <motion.span
          key={burst.id}
          className="fixed z-[2147483646] pointer-events-none rounded-full border border-[#D8D000] shadow-[0_0_16px_rgba(25,167,216,.75)]"
          style={{ left: burst.x, top: burst.y, translateX: '-50%', translateY: '-50%' }}
          initial={{ opacity: 0.95, width: 7, height: 7 }}
          animate={{ opacity: 0, width: 30, height: 30 }}
          transition={{ duration: 0.48, ease: 'easeOut' }}
        />
      ))}

      <motion.div
        className="fixed left-0 top-0 z-[2147483647] pointer-events-none select-none"
        // The PNG's brush tip is at its top-left corner, so the tip—not its center—tracks the real pointer.
        style={{ x: sx, y: sy, translateX: 0, translateY: 0, opacity: visible ? 1 : 0 }}
        animate={{ scale: hovered ? 1.06 : 1, rotate: hovered ? -3 : 0 }}
        transition={{ type: 'spring', stiffness: 320, damping: 22 }}
      >
        <motion.img
          src="/assets/paintbrush-cursor.png"
          alt=""
          aria-hidden="true"
          className="block w-[78px] h-auto max-w-none drop-shadow-[0_5px_10px_rgba(0,0,0,.55)]"
          animate={{ y: [0, -1.5, 0], x: [0, 1, 0] }}
          transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
        />
      </motion.div>
    </>
  );
};
