import React from 'react';
import { motion } from 'framer-motion';
import { WhatsAppIcon, LinkedInIcon } from './SocialIcons';

// Easy-to-edit placeholder URL - replace with your actual LinkedIn profile link when ready
export const LINKEDIN_URL = "https://www.linkedin.com/";

export const FixedSocialBar: React.FC = () => {
  return (
    <aside
      aria-label="Social Media Links"
      className="fixed left-2 sm:left-6 md:left-8 lg:left-12 xl:left-14 top-1/2 -translate-y-1/2 z-50 select-none pointer-events-none"
    >
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6, delay: 0.2, ease: [0.25, 0.1, 0.25, 1] }}
        className="flex flex-col items-center gap-2 sm:gap-4"
      >
        {/* Subtle decorative vertical line top */}
        <div className="hidden sm:block w-px h-8 md:h-12 bg-gradient-to-t from-[#121212]/20 to-transparent" />

        {/* WhatsApp Direct Chat */}
        <motion.a
          href="https://wa.me/919627616226"
          target="_blank"
          rel="noopener noreferrer"
          whileHover={{ scale: 1.15, x: 2 }}
          whileTap={{ scale: 0.95 }}
          transition={{ duration: 0.2 }}
          aria-label="Chat directly on WhatsApp (+234 702 046 6988)"
          className="group pointer-events-auto w-7 h-7 sm:w-10 sm:h-10 rounded-full flex items-center justify-center border border-[#121212]/15 bg-[#E7E4DC]/75 hover:bg-[#E7E4DC]/95 backdrop-blur-md text-[#121212] hover:text-[#121212] hover:border-[#B8B000]/60 hover:shadow-[0_0_16px_rgba(192,132,252,0.45)] transition-all duration-300 cursor-pointer shadow-lg"
        >
          <div className="w-3 h-3 sm:w-[18px] sm:h-[18px] flex items-center justify-center transition-transform duration-200 group-hover:scale-110">
            <WhatsAppIcon className="w-full h-full fill-current" />
          </div>
        </motion.a>

        {/* LinkedIn Profile */}
        <motion.a
          href={LINKEDIN_URL}
          target="_blank"
          rel="noopener noreferrer"
          whileHover={{ scale: 1.15, x: 2 }}
          whileTap={{ scale: 0.95 }}
          transition={{ duration: 0.2 }}
          aria-label="Visit LinkedIn profile"
          className="group pointer-events-auto w-7 h-7 sm:w-10 sm:h-10 rounded-full flex items-center justify-center border border-[#121212]/15 bg-[#E7E4DC]/75 hover:bg-[#E7E4DC]/95 backdrop-blur-md text-[#121212] hover:text-[#121212] hover:border-[#B8B000]/60 hover:shadow-[0_0_16px_rgba(192,132,252,0.45)] transition-all duration-300 cursor-pointer shadow-lg"
        >
          <div className="w-3 h-3 sm:w-[18px] sm:h-[18px] flex items-center justify-center transition-transform duration-200 group-hover:scale-110">
            <LinkedInIcon className="w-full h-full fill-current" />
          </div>
        </motion.a>

        {/* Subtle decorative vertical line bottom */}
        <div className="hidden sm:block w-px h-8 md:h-12 bg-gradient-to-b from-[#121212]/20 to-transparent" />
      </motion.div>
    </aside>
  );
};
