import React, { useEffect, useRef } from 'react';

// A horizontal digital fluid ribbon with interactive spline nodes and wave physics
interface FluidRibbon {
  baseOffsetY: number;
  widthMax: number;
  speed1: number;
  speed2: number;
  freq1: number;
  freq2: number;
  amp1: number;
  amp2: number;
  phase1: number;
  phase2: number;
  strandCount: number;
  colorCore: string;
  colorHighlight: string;
  colorAccent: string;
  alphaBase: number;
  nodes: {
    y: number;
    vy: number;
    baseY: number;
  }[];
}

// Micro-dust particle for subtle edge texture (fluid -> particles -> dust)
interface DustParticle {
  ribbonIndex: number;
  u: number; // progress along ribbon [0, 1]
  speed: number;
  offsetY: number;
  driftVy: number;
  radius: number;
  alpha: number;
  maxAlpha: number;
  life: number;
  maxLife: number;
  isDetached: boolean;
  color: { r: number; g: number; b: number };
}

export const ParticleHeroCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let animationFrameId: number;
    let width = 0;
    let height = 0;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    // Mouse tracking state for fluid interaction
    const mouse = {
      x: -9999,
      y: -9999,
      prevX: -9999,
      prevY: -9999,
      vx: 0,
      vy: 0,
      speed: 0,
      isActive: false,
      hasEverMoved: false,
    };

    // Node resolution across the horizontal ribbon width
    const NODE_COUNT = 38;

    // 4 Layered flowing digital fluid streams (Upper wave, Core liquid-light, Lower wave, Ambient deep silk)
    const ribbons: FluidRibbon[] = [
      // 1. Core Liquid Light (flowing directly behind text, high cyan & electric blue vibrancy)
      {
        baseOffsetY: -4,
        widthMax: 90,
        speed1: 0.0014,
        speed2: 0.0021,
        freq1: 3.2,
        freq2: 5.8,
        amp1: 28,
        amp2: 18,
        phase1: 0.0,
        phase2: 1.4,
        strandCount: 9,
        colorCore: 'rgba(37, 99, 235, 0.42)', // electric blue
        colorHighlight: 'rgba(6, 182, 212, 0.58)', // vivid cyan
        colorAccent: 'rgba(124, 58, 237, 0.35)', // subtle violet
        alphaBase: 0.45,
        nodes: [],
      },
      // 2. Upper Silk Ribbon (framing upper edge of typography)
      {
        baseOffsetY: -42,
        widthMax: 70,
        speed1: 0.0011,
        speed2: 0.0018,
        freq1: 2.6,
        freq2: 4.4,
        amp1: 24,
        amp2: 14,
        phase1: 1.2,
        phase2: 2.8,
        strandCount: 7,
        colorCore: 'rgba(29, 78, 216, 0.32)', // deep cobalt
        colorHighlight: 'rgba(56, 189, 248, 0.46)', // bright sky cyan
        colorAccent: 'rgba(147, 51, 234, 0.30)', // royal violet
        alphaBase: 0.35,
        nodes: [],
      },
      // 3. Lower Flowing Stream (weaving below the letters)
      {
        baseOffsetY: 38,
        widthMax: 75,
        speed1: 0.0016,
        speed2: 0.0024,
        freq1: 3.0,
        freq2: 5.2,
        amp1: 26,
        amp2: 16,
        phase1: 2.5,
        phase2: 0.8,
        strandCount: 7,
        colorCore: 'rgba(59, 130, 246, 0.34)', // vibrant blue
        colorHighlight: 'rgba(14, 165, 233, 0.50)', // cyan highlight
        colorAccent: 'rgba(109, 40, 217, 0.28)', // deep violet
        alphaBase: 0.38,
        nodes: [],
      },
      // 4. Ambient Deep Plume (wide soft background veil providing volumetric dark depth)
      {
        baseOffsetY: -8,
        widthMax: 135,
        speed1: 0.0008,
        speed2: 0.0013,
        freq1: 1.8,
        freq2: 3.2,
        amp1: 35,
        amp2: 20,
        phase1: 3.8,
        phase2: 4.5,
        strandCount: 5,
        colorCore: 'rgba(30, 58, 138, 0.22)', // deep midnight blue
        colorHighlight: 'rgba(124, 58, 237, 0.24)', // translucent violet
        colorAccent: 'rgba(6, 182, 212, 0.18)', // soft cyan haze
        alphaBase: 0.25,
        nodes: [],
      },
    ];

    // Initialize spline nodes for each ribbon
    const initRibbons = () => {
      for (const r of ribbons) {
        r.nodes = [];
        for (let i = 0; i < NODE_COUNT; i++) {
          r.nodes.push({
            y: 0,
            vy: 0,
            baseY: 0,
          });
        }
      }
    };

    initRibbons();

    // Subtle edge dust particles: 180 micro-particles riding and detaching from fluid edges
    const dustColors = [
      { r: 6, g: 182, b: 212 },   // cyan
      { r: 56, g: 189, b: 248 },  // bright cyan
      { r: 125, g: 211, b: 252 }, // ice blue
      { r: 147, g: 51, b: 234 },  // violet
      { r: 224, g: 242, b: 254 }, // white-blue spark
    ];

    const dustCount = 190;
    const dustParticles: DustParticle[] = [];

    const spawnDust = (p: DustParticle, initial = false) => {
      p.ribbonIndex = Math.floor(Math.random() * ribbons.length);
      p.u = initial ? 0.1 + Math.random() * 0.8 : 0.08 + Math.random() * 0.15;
      p.speed = 0.0006 + Math.random() * 0.0014;
      p.offsetY = (Math.random() - 0.5) * 20;
      p.driftVy = (Math.random() - 0.5) * 0.35;
      p.radius = 0.5 + Math.random() * 0.85; // extremely fine micro-dust
      p.maxAlpha = 0.3 + Math.random() * 0.55;
      p.alpha = initial ? Math.random() * p.maxAlpha : 0.01;
      p.life = 0;
      p.maxLife = 180 + Math.random() * 260;
      p.isDetached = Math.random() > 0.65; // some particles detach and dissolve
      p.color = dustColors[Math.floor(Math.random() * dustColors.length)];
    };

    for (let i = 0; i < dustCount; i++) {
      const p: DustParticle = {
        ribbonIndex: 0,
        u: 0,
        speed: 0,
        offsetY: 0,
        driftVy: 0,
        radius: 0.8,
        alpha: 0,
        maxAlpha: 0.5,
        life: 0,
        maxLife: 200,
        isDetached: false,
        color: dustColors[0],
      };
      spawnDust(p, true);
      dustParticles.push(p);
    }

    const updateDimensions = () => {
      width = container.clientWidth;
      height = container.clientHeight;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.scale(dpr, dpr);
    };

    updateDimensions();

    const isTouchDevice = window.matchMedia('(pointer: coarse)').matches;

    // Mouse movement: acts as a force moving through the liquid
    const handleMouseMove = (e: MouseEvent) => {
      if (isTouchDevice) return;
      const rect = container.getBoundingClientRect();
      const currentX = e.clientX - rect.left;
      const currentY = e.clientY - rect.top;

      if (
        e.clientX >= rect.left - 50 &&
        e.clientX <= rect.right + 50 &&
        e.clientY >= rect.top - 50 &&
        e.clientY <= rect.bottom + 50
      ) {
        if (!mouse.hasEverMoved) {
          mouse.prevX = currentX;
          mouse.prevY = currentY;
          mouse.x = currentX;
          mouse.y = currentY;
          mouse.hasEverMoved = true;
        }

        const instantVx = currentX - mouse.prevX;
        const instantVy = currentY - mouse.prevY;
        mouse.vx = instantVx;
        mouse.vy = instantVy;
        mouse.speed = Math.hypot(instantVx, instantVy);

        mouse.x = currentX;
        mouse.y = currentY;
        mouse.isActive = true;
      } else {
        mouse.isActive = false;
      }
    };

    const handleMouseLeave = () => {
      mouse.isActive = false;
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    document.addEventListener('mouseleave', handleMouseLeave);

    const handleResize = () => {
      updateDimensions();
    };
    window.addEventListener('resize', handleResize, { passive: true });

    let isTabVisible = true;
    const handleVisibilityChange = () => {
      isTabVisible = !document.hidden;
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Animation loop
    const render = (time: number) => {
      if (!isTabVisible) {
        animationFrameId = requestAnimationFrame(render);
        return;
      }

      ctx.clearRect(0, 0, width, height);

      // Smooth decay of mouse velocity
      mouse.vx *= 0.85;
      mouse.vy *= 0.85;
      mouse.speed *= 0.85;
      mouse.prevX = mouse.x;
      mouse.prevY = mouse.y;

      const centerY = height * 0.48; // Centered directly behind typography
      // Fluid ribbon width matches the wide typography with breathing room
      const fluidWidth = Math.min(width * 0.90, 1260);
      const startX = (width - fluidWidth) * 0.5;

      const influenceRadius = 175;

      // 1. UPDATE SPLINE NODES WITH WAVE EQUATIONS & LIQUID MOUSE INTERACTION
      for (let rIdx = 0; rIdx < ribbons.length; rIdx++) {
        const r = ribbons[rIdx];
        const count = r.nodes.length;

        for (let i = 0; i < count; i++) {
          const u = i / (count - 1); // [0, 1] across fluid width
          const nodeX = startX + u * fluidWidth;

          // Natural organic flowing wave motion (left -> center -> right)
          const wave1 = Math.sin(u * r.freq1 * Math.PI + time * r.speed1 + r.phase1) * r.amp1;
          const wave2 = Math.cos(u * r.freq2 * Math.PI - time * r.speed2 + r.phase2) * r.amp2;
          const baselineY = centerY + r.baseOffsetY + wave1 + wave2;

          r.nodes[i].baseY = baselineY;

          // Mouse fluid shear force
          if (mouse.isActive && !isTouchDevice) {
            const dx = nodeX - mouse.x;
            const dy = r.nodes[i].y - mouse.y;
            const dist = Math.hypot(dx, dy);

            if (dist < influenceRadius && dist > 1) {
              const normDist = dist / influenceRadius;
              const proximity = (1 - normDist) * (1 - normDist);
              const forceScale = proximity * (0.35 + Math.min(mouse.speed * 0.08, 1.4));

              // Fluid pushes away from cursor vertically and drags in cursor movement direction
              const pushY = (dy / dist) * forceScale * 3.4;
              const dragY = mouse.vy * forceScale * 0.12;

              r.nodes[i].vy += pushY + dragY;
            }
          }

          // Elastic tension between neighboring nodes (wave propagation through liquid)
          let neighborAvg = r.nodes[i].y;
          if (i > 0 && i < count - 1) {
            neighborAvg = (r.nodes[i - 1].y + r.nodes[i + 1].y) * 0.5;
          } else if (i === 0) {
            neighborAvg = r.nodes[1].y;
          } else {
            neighborAvg = r.nodes[count - 2].y;
          }
          const tensionForce = (neighborAvg - r.nodes[i].y) * 0.075;

          // Damped spring restoration back toward wave baseline
          const restoreForce = (r.nodes[i].baseY - r.nodes[i].y) * 0.024;

          r.nodes[i].vy = (r.nodes[i].vy + restoreForce + tensionForce) * 0.895;
          r.nodes[i].y += r.nodes[i].vy;
        }
      }

      // Helper to evaluate ribbon height at normalized u [0, 1] using Catmull-Rom interpolation
      const getRibbonPoint = (ribbonIndex: number, u: number) => {
        const r = ribbons[ribbonIndex];
        const nodes = r.nodes;
        const total = nodes.length;
        const clampedU = Math.max(0, Math.min(1, u));
        const indexFloat = clampedU * (total - 1);
        const i0 = Math.floor(indexFloat);
        const frac = indexFloat - i0;

        const p0 = nodes[Math.max(0, i0 - 1)].y;
        const p1 = nodes[i0].y;
        const p2 = nodes[Math.min(total - 1, i0 + 1)].y;
        const p3 = nodes[Math.min(total - 1, i0 + 2)].y;

        // Catmull-Rom spline
        const y =
          0.5 *
          (2 * p1 +
            (-p0 + p2) * frac +
            (2 * p0 - 5 * p1 + 4 * p2 - p3) * frac * frac +
            (-p0 + 3 * p1 - 3 * p2 + p3) * frac * frac * frac);

        const x = startX + clampedU * fluidWidth;
        return { x, y };
      };

      // 2. RENDER FLOWING TRANSLUCENT DIGITAL FLUID RIBBONS
      // Use screen blending for ethereal liquid light and vibrant optical overlap
      ctx.globalCompositeOperation = 'screen';

      for (let rIdx = 0; rIdx < ribbons.length; rIdx++) {
        const r = ribbons[rIdx];
        const nodes = r.nodes;
        const count = nodes.length;

        // Dynamic width envelope: tapers to zero at both ends (no box edges, seamless dissolution into black)
        const getWidthAt = (u: number) => {
          // Smooth sine envelope ensuring complete 0 width at extremities
          const env = Math.sin(Math.max(0, Math.min(1, u)) * Math.PI);
          return r.widthMax * Math.pow(env, 1.25);
        };

        // A. Draw multiple flowing translucent internal silk filaments
        for (let s = 0; s < r.strandCount; s++) {
          const strandFrac = (s / (r.strandCount - 1) - 0.5) * 2; // in [-1, 1]
          const strandAlpha =
            (1 - Math.abs(strandFrac) * 0.45) *
            r.alphaBase *
            (0.5 + 0.5 * Math.sin(time * 0.0018 + s * 1.1));

          if (strandAlpha <= 0.01) continue;

          // Color gradient across the strand (violet -> deep electric blue -> cyan -> violet)
          const grad = ctx.createLinearGradient(startX, 0, startX + fluidWidth, 0);
          grad.addColorStop(0, 'rgba(18, 38, 90, 0)');
          grad.addColorStop(0.18, r.colorAccent);
          grad.addColorStop(0.48, r.colorHighlight);
          grad.addColorStop(0.68, r.colorCore);
          grad.addColorStop(0.86, r.colorAccent);
          grad.addColorStop(1, 'rgba(18, 38, 90, 0)');

          ctx.beginPath();
          for (let i = 0; i < count; i++) {
            const u = i / (count - 1);
            const w = getWidthAt(u);
            const microWave = Math.sin(time * 0.0022 + u * 12 + s * 0.8) * (w * 0.08);
            const x = startX + u * fluidWidth;
            const y = nodes[i].y + strandFrac * (w * 0.48) + microWave;

            if (i === 0) {
              ctx.moveTo(x, y);
            } else {
              const prevU = (i - 1) / (count - 1);
              const prevW = getWidthAt(prevU);
              const prevX = startX + prevU * fluidWidth;
              const prevY = nodes[i - 1].y + strandFrac * (prevW * 0.48);
              const xc = (prevX + x) * 0.5;
              const yc = (prevY + y) * 0.5;
              ctx.quadraticCurveTo(prevX, prevY, xc, yc);
            }
          }

          ctx.strokeStyle = grad;
          // Varying strand line weight creates silk-like depth
          ctx.lineWidth = s === Math.floor(r.strandCount / 2) ? 2.4 : 1.2;
          ctx.stroke();
        }

        // B. Volumetric translucent ribbon body fill with soft falloff
        ctx.beginPath();
        // Top edge (left to right)
        for (let i = 0; i < count; i++) {
          const u = i / (count - 1);
          const halfW = getWidthAt(u) * 0.5;
          const x = startX + u * fluidWidth;
          const y = nodes[i].y - halfW;
          if (i === 0) ctx.moveTo(x, y);
          else {
            const prevU = (i - 1) / (count - 1);
            const prevHalfW = getWidthAt(prevU) * 0.5;
            const prevX = startX + prevU * fluidWidth;
            const prevY = nodes[i - 1].y - prevHalfW;
            const xc = (prevX + x) * 0.5;
            const yc = (prevY + y) * 0.5;
            ctx.quadraticCurveTo(prevX, prevY, xc, yc);
          }
        }
        // Bottom edge (right to left)
        for (let i = count - 1; i >= 0; i--) {
          const u = i / (count - 1);
          const halfW = getWidthAt(u) * 0.5;
          const x = startX + u * fluidWidth;
          const y = nodes[i].y + halfW;
          const nextU = (i + 1) / (count - 1);
          const nextHalfW = getWidthAt(Math.min(1, nextU)) * 0.5;
          const nextX = startX + Math.min(1, nextU) * fluidWidth;
          const nextY = nodes[Math.min(count - 1, i + 1)].y + nextHalfW;
          const xc = (nextX + x) * 0.5;
          const yc = (nextY + y) * 0.5;
          ctx.quadraticCurveTo(nextX, nextY, xc, yc);
        }
        ctx.closePath();

        const bodyGrad = ctx.createLinearGradient(startX, 0, startX + fluidWidth, 0);
        bodyGrad.addColorStop(0, 'rgba(12, 12, 12, 0)');
        bodyGrad.addColorStop(0.20, r.colorAccent);
        bodyGrad.addColorStop(0.50, r.colorCore);
        bodyGrad.addColorStop(0.75, r.colorHighlight);
        bodyGrad.addColorStop(1, 'rgba(12, 12, 12, 0)');

        ctx.fillStyle = bodyGrad;
        ctx.fill();
      }

      // 3. SUBTLE EDGE PARTICLES & EVAPORATING DUST (fluid -> particles -> dust)
      for (let i = 0; i < dustCount; i++) {
        const p = dustParticles[i];

        // Advance along ribbon
        p.u += p.speed;
        p.life++;

        // Envelope fades in and out smoothly
        const lifeRatio = p.life / p.maxLife;
        if (p.u >= 0.92 || lifeRatio >= 1) {
          spawnDust(p);
          continue;
        }

        // Fade in rapidly, fade out as it reaches the end or detaches
        const alphaEnvelope =
          lifeRatio < 0.2
            ? lifeRatio / 0.2
            : lifeRatio > 0.7
            ? (1 - lifeRatio) / 0.3
            : 1.0;

        const currentAlpha = p.maxAlpha * alphaEnvelope;
        if (currentAlpha <= 0.01) continue;

        // Sample position from parent ribbon
        const ribbonPt = getRibbonPoint(p.ribbonIndex, p.u);

        // If detached, drift gently away from the ribbon surface like evaporating smoke
        if (p.isDetached) {
          p.offsetY += p.driftVy;
        }

        const px = ribbonPt.x;
        const py = ribbonPt.y + p.offsetY;

        // Draw micro-dust speck
        ctx.beginPath();
        ctx.arc(px, py, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${p.color.r}, ${p.color.g}, ${p.color.b}, ${currentAlpha})`;
        ctx.fill();

        // Subtle glowing micro-aura on select brighter particles
        if (p.radius > 0.95 && currentAlpha > 0.3) {
          ctx.beginPath();
          ctx.arc(px, py, p.radius * 2.5, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(${p.color.r}, ${p.color.g}, ${p.color.b}, ${currentAlpha * 0.2})`;
          ctx.fill();
        }
      }

      ctx.globalCompositeOperation = 'source-over';
      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('resize', handleResize);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 w-full h-full pointer-events-none select-none overflow-hidden z-0"
      aria-hidden="true"
    >
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
};


