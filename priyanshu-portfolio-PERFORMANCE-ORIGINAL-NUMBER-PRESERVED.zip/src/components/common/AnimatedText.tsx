import React, { useRef, useMemo } from 'react';
import { motion, useScroll, useTransform, MotionValue } from 'framer-motion';

interface CharacterSpanProps {
  char: string;
  progress: MotionValue<number>;
  range: [number, number];
}

const CharacterSpan: React.FC<CharacterSpanProps> = ({ char, progress, range }) => {
  const opacity = useTransform(progress, range, [0.38, 1]);

  return (
    <span className="relative inline-block">
      <span className="opacity-0 select-none">{char}</span>
      <motion.span
        className="absolute top-0 left-0"
        style={{ opacity }}
      >
        {char}
      </motion.span>
    </span>
  );
};

interface AnimatedTextProps {
  text: string;
  className?: string;
}

export const AnimatedText: React.FC<AnimatedTextProps> = ({ text, className = '' }) => {
  const containerRef = useRef<HTMLParagraphElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start 0.8', 'end 0.2'],
  });

  const words = useMemo(() => text.split(' '), [text]);
  const totalChars = useMemo(() => text.length, [text]);

  // Precompute ranges for each character so render is fast
  const wordTokens = useMemo(() => {
    let index = 0;
    return words.map((word) => {
      const chars = word.split('').map((char) => {
        const start = index / totalChars;
        const end = Math.min(1, (index + 2) / totalChars);
        index++;
        return { char, range: [start, end] as [number, number] };
      });
      // Increment for the space after word
      index++;
      return chars;
    });
  }, [words, totalChars]);

  return (
    <p ref={containerRef} className={className}>
      {wordTokens.map((chars, wordIdx) => (
        <span key={wordIdx} className="inline-block whitespace-nowrap">
          {chars.map(({ char, range }, charIdx) => (
            <CharacterSpan
              key={charIdx}
              char={char}
              progress={scrollYProgress}
              range={range}
            />
          ))}
          {wordIdx < wordTokens.length - 1 && (
            <span className="inline-block">&nbsp;</span>
          )}
        </span>
      ))}
    </p>
  );
};
