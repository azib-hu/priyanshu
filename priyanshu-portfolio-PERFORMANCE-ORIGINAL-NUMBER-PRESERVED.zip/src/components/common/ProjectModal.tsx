import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { ProjectItem } from '../../types';
import { ContactButton } from './ContactButton';


const VariCaseStudy: React.FC = () => (
  <div className="space-y-5 sm:space-y-7">
    <div className="overflow-hidden rounded-[18px] sm:rounded-[26px] border border-white/10 bg-[#0D0F12] shadow-2xl">
      <img
        src="/assets/projects/vari-art-banner.webp"
        alt="VARI / ART conceptual identity presentation"
        className="w-full h-auto object-contain"
      / decoding="async">
    </div>

    <div className="grid grid-cols-1 lg:grid-cols-[1.45fr_0.75fr] gap-3 sm:gap-4">
      <div className="p-4 sm:p-6 rounded-2xl bg-[#1A1E23] border border-white/10">
        <div className="flex items-center gap-2 mb-2.5"><span className="h-px w-7 bg-[#19A7D8]" /><span className="text-[9px] uppercase tracking-[0.2em] text-[#19A7D8] font-semibold">Project Overview</span></div>
        <p className="text-xs sm:text-sm leading-relaxed text-[#D7DBE0]">VARI / ART is a conceptual identity project exploring dual perception through typographical minimalism. The identity is engineered around a single continuous-stroke wordmark capable of two simultaneous readings: VARI (variation) and ART (creation).</p>
      </div>
      <div className="p-4 sm:p-6 rounded-2xl bg-[#1A1E23] border border-white/10">
        <div className="flex items-center gap-2 mb-2.5"><span className="h-px w-7 bg-[#19A7D8]" /><span className="text-[9px] uppercase tracking-[0.2em] text-[#19A7D8] font-semibold">My Role</span></div>
        <p className="text-xs sm:text-sm leading-relaxed text-[#D7DBE0]">Identity Designer / Typographer</p>
      </div>
    </div>

    <section>
      <div className="flex items-center gap-2 mb-3"><span className="h-px w-7 bg-white/20" /><span className="text-[9px] uppercase tracking-[0.2em] text-[#8E969F]">The Challenge &amp; Creative Brief</span></div>
      <div className="p-4 sm:p-6 rounded-2xl bg-[#1A1E23] border border-white/10">
        <p className="text-xs sm:text-sm leading-relaxed text-[#C7CCD2]">Modern creative studios, generative platforms and design collectives often need to bridge technical process and artistic outcome. The brief was to express both Variation — iteration, multiplicity and dynamic systems — and Creation — human craft, deliberate expression and final execution — through one stripped-back typographic construction.</p>
      </div>
    </section>

    <section>
      <div className="flex items-center gap-2 mb-3"><span className="h-px w-7 bg-white/20" /><span className="text-[9px] uppercase tracking-[0.2em] text-[#8E969F]">The Core Concept</span></div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        {[['V','Shared Stem','A continuous rhythmic monoline stroke establishes the visual identity.'],['A','Shared R','The R acts as the visual anchor and remains preserved across both interpretations.'],['R','The I → T Shift','The final letterform changes role so the second reading can emerge.'],['I / T','Gesture & Flow','Curved transition nodes balance brush-like fluidity with vector precision.']].map(([title,sub,copy],i)=>(
          <div key={i} className="p-3.5 sm:p-4 rounded-xl bg-[#171B20] border border-white/10 min-h-[132px]">
            <div className="text-[8px] uppercase tracking-[0.18em] text-[#19A7D8]">{sub}</div>
            <div className="mt-2 text-xl sm:text-2xl font-black text-[#F4F1EA]">{title}</div>
            <p className="mt-2 text-[10px] sm:text-xs leading-relaxed text-[#9FA7B0]">{copy}</p>
          </div>
        ))}
      </div>
    </section>

    <section>
      <div className="flex items-center gap-2 mb-3"><span className="h-px w-7 bg-white/20" /><span className="text-[9px] uppercase tracking-[0.2em] text-[#8E969F]">Visual System &amp; Minimality</span></div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
        {[['Colour','Deep Charcoal #111111 + Pure White #FFFFFF','A deliberately monochromatic identity keeps the wordmark at the centre.'],['Typography','Custom monoline script + geometric sans-serif','The custom stroke carries the concept while the secondary type keeps information precise.'],['Material','Uncoated stock + restrained finish','The physical direction keeps the identity tactile without competing with the mark.']].map(([h,v,c],i)=>(
          <div key={i} className="p-4 rounded-xl bg-[#171B20] border border-white/10">
            <div className="text-[8px] uppercase tracking-[0.18em] text-[#19A7D8]">{h}</div>
            <h4 className="mt-2 text-xs sm:text-sm font-bold text-[#F4F1EA]">{v}</h4>
            <p className="mt-2 text-[10px] sm:text-xs leading-relaxed text-[#9FA7B0]">{c}</p>
          </div>
        ))}
      </div>
    </section>

    <section>
      <div className="flex items-center gap-2 mb-3"><span className="h-px w-7 bg-white/20" /><span className="text-[9px] uppercase tracking-[0.2em] text-[#8E969F]">Brand Applications</span></div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
        {['Print / Ephemera — business cards, textured black paper and restrained foil/deboss treatments.','Digital / App Iconography — the R–i/t intersection can become a compact recognisable crop.','Merchandise / Studio Touchpoints — the identity can extend to embossed goods, pins and screen-printed packaging.'].map((t,i)=>(
          <div key={i} className="p-4 rounded-xl bg-[#171B20] border border-white/10 text-[10px] sm:text-xs leading-relaxed text-[#A7ABB2]">{t}</div>
        ))}
      </div>
    </section>

    <section className="p-5 sm:p-7 rounded-2xl bg-[#111418] border border-[#19A7D8]/30">
      <div className="text-[8px] uppercase tracking-[0.18em] text-[#19A7D8]">Key Takeaway</div>
      <h4 className="mt-2 text-xl sm:text-3xl font-black uppercase tracking-[-0.03em] text-[#F4F1EA]">ONE WORD. TWO READINGS. ENDLESS POSSIBILITIES.</h4>
      <p className="mt-3 text-xs sm:text-sm leading-relaxed text-[#A7ABB2]">The identity works as a small puzzle of perception: the same structure can reveal a different meaning through close inspection, turning repetition and structure into the core of the visual language.</p>
    </section>

    <section>
      <div className="flex items-center gap-2 mb-3"><span className="h-px w-7 bg-white/20" /><span className="text-[9px] uppercase tracking-[0.2em] text-[#8E969F]">Additional Visuals</span></div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <img src="/assets/projects/vari-art-showcase.webp" alt="VARI / ART identity showcase" className="w-full rounded-xl border border-white/10" / decoding="async">
        <img src="/assets/projects/vari-art.webp" alt="VARI / ART identity artwork" className="w-full rounded-xl border border-white/10" / decoding="async">
      </div>
    </section>
  </div>
);


const LogoRedesignCaseStudy: React.FC = () => (
  <div className="space-y-6 sm:space-y-9">
    <div>
      <h3 className="text-2xl sm:text-5xl md:text-6xl font-black uppercase tracking-[-0.04em] leading-[0.9] text-[#F4F1EA]">
        Logo Redesign —<br className="hidden sm:block" /> Conceptual Rebrand
      </h3>
      <p className="mt-3 text-sm sm:text-lg text-[#A7ABB2] leading-relaxed max-w-3xl">
        An unofficial redesign exercise exploring a new visual direction for an existing mark.
      </p>
      <div className="mt-5 flex flex-wrap gap-2">
        {['Adobe Illustrator', 'Concept Presentation'].map((tool) => (
          <span key={tool} className="px-3 py-1.5 rounded-full border border-white/10 text-[9px] uppercase tracking-[0.16em] text-[#A7ABB2]">{tool}</span>
        ))}
      </div>
    </div>

    <div className="overflow-hidden rounded-[20px] sm:rounded-[30px] border border-white/10 bg-[#0D0F12] shadow-2xl">
      <img src="/assets/projects/logo-redesign-mockup.webp" alt="Logo redesign conceptual rebrand mockup" className="w-full h-auto object-cover" / decoding="async">
    </div>

    <div className="grid grid-cols-1 lg:grid-cols-[1.45fr_0.8fr] gap-4 sm:gap-5">
      <div className="p-5 sm:p-7 rounded-[20px] sm:rounded-[26px] bg-[#1D2229] border border-white/10">
        <div className="flex items-center gap-3 mb-3"><span className="h-px w-8 bg-[#19A7D8]" /><span className="text-[10px] uppercase tracking-[0.2em] text-[#19A7D8] font-semibold">Project Overview</span></div>
        <p className="text-sm sm:text-base leading-relaxed text-[#D7DBE0]">A conceptual / unofficial logo redesign exercise presented as a design exploration, not as commissioned brand work. The source presentation explores a new visual direction for 1.1.1.1 (Cloudflare VPN).</p>
      </div>
      <div className="p-5 sm:p-7 rounded-[20px] sm:rounded-[26px] bg-[#1D2229] border border-white/10">
        <div className="flex items-center gap-3 mb-3"><span className="h-px w-8 bg-[#19A7D8]" /><span className="text-[10px] uppercase tracking-[0.2em] text-[#19A7D8] font-semibold">My Role</span></div>
        <p className="text-sm sm:text-base leading-relaxed text-[#D7DBE0]">Graphic Designer — logo redesign, visual exploration and presentation design.</p>
      </div>
    </div>

    <section>
      <div className="flex items-center gap-3 mb-4"><span className="h-px w-8 bg-white/20" /><span className="text-[10px] uppercase tracking-[0.2em] text-[#9199A3]">01 · Brand Context</span></div>
      <div className="grid grid-cols-1 lg:grid-cols-[1.2fr_0.8fr] gap-4">
        <div className="p-5 sm:p-7 rounded-[20px] bg-[#171B20] border border-white/10">
          <h4 className="text-xl sm:text-3xl font-black uppercase tracking-[-0.03em] text-[#F4F1EA]">1.1.1.1 / Cloudflare</h4>
          <p className="mt-3 text-sm sm:text-base leading-relaxed text-[#A7ABB2]">The source presentation describes 1.1.1.1 as a DNS resolver and VPN service by Cloudflare, focused on faster and more private internet browsing.</p>
        </div>
        <div className="p-5 sm:p-7 rounded-[20px] bg-[#171B20] border border-white/10">
          <div className="text-[9px] uppercase tracking-[0.18em] text-[#19A7D8]">Target audience</div>
          <p className="mt-2 text-sm text-[#E2E5E9]">Tech-savvy users and professionals who care about secure, fast and private browsing.</p>
          <div className="mt-4 text-[9px] uppercase tracking-[0.18em] text-[#19A7D8]">Values</div>
          <div className="mt-2 flex flex-wrap gap-2">{['Privacy & Security','Speed & Efficiency','Freedom & Trust'].map(v => <span key={v} className="px-2.5 py-1.5 rounded-full border border-white/10 text-[9px] text-[#C7CCD2]">{v}</span>)}</div>
        </div>
      </div>
    </section>

    <section>
      <div className="flex items-center gap-3 mb-4"><span className="h-px w-8 bg-white/20" /><span className="text-[10px] uppercase tracking-[0.2em] text-[#9199A3]">02 · Core Idea / New Concept</span></div>
      <div className="grid grid-cols-1 md:grid-cols-[1fr_0.9fr] gap-4 items-center">
        <div className="p-5 sm:p-7 rounded-[20px] bg-[#171B20] border border-white/10">
          <h4 className="text-2xl sm:text-4xl font-black uppercase tracking-[-0.035em] text-[#F4F1EA]">Global Security Network</h4>
          <p className="mt-3 text-sm sm:text-base leading-relaxed text-[#A7ABB2]">The redesign visualises the service as a global security network. The concept combines a central 1, four directional arrows for connection, and a globe for worldwide access.</p>
        </div>
        <div className="overflow-hidden rounded-[20px] border border-white/10 bg-[#0F1115]"><img src="/assets/projects/logo-redesign-page-4.webp" alt="Logo redesign concept diagram" className="w-full h-auto" / decoding="async"></div>
      </div>
    </section>

    <section>
      <div className="flex items-center gap-3 mb-4"><span className="h-px w-8 bg-white/20" /><span className="text-[10px] uppercase tracking-[0.2em] text-[#9199A3]">03 · Design Process</span></div>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {[
          ['/assets/projects/logo-redesign-page-2.webp','Research & Understanding','Brand introduction, audience and values.'],
          ['/assets/projects/logo-redesign-page-3.webp','Original Mark Review','Breaking down the existing 1.1.1.1 visual language.'],
          ['/assets/projects/logo-redesign-page-5.webp','Exploration & Refinement','Exploring directions before refining the final concept.']
        ].map(([img,title,copy], i) => (
          <div key={title} className="rounded-[18px] bg-[#171B20] border border-white/10 overflow-hidden">
            <img src={img} alt={title} className="w-full aspect-[16/9] object-cover" / decoding="async">
            <div className="p-4"><span className="text-[9px] text-[#19A7D8] font-bold">0{i + 1}</span><h5 className="mt-1.5 text-sm font-bold uppercase text-[#F4F1EA]">{title}</h5><p className="mt-2 text-xs leading-relaxed text-[#9FA7B0]">{copy}</p></div>
          </div>
        ))}
      </div>
    </section>

    <section>
      <div className="flex items-center gap-3 mb-4"><span className="h-px w-8 bg-white/20" /><span className="text-[10px] uppercase tracking-[0.2em] text-[#9199A3]">04 · Visual System</span></div>
      <div className="overflow-hidden rounded-[20px] border border-white/10 bg-white"><img src="/assets/projects/logo-redesign-page-6.webp" alt="Logo redesign meaning and final logo" className="w-full h-auto" / decoding="async"></div>
    </section>

    <section>
      <div className="flex items-center gap-3 mb-4"><span className="h-px w-8 bg-white/20" /><span className="text-[10px] uppercase tracking-[0.2em] text-[#9199A3]">05 · Meaning</span></div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          ['Four Arrows','Connection in all directions.'],
          ['The Central 1','Identity and data security.'],
          ['The Globe','Worldwide access and a global network.'],
          ['Gradient','Technology and energy flow.']
        ].map(([h,c], i) => <div key={h} className="p-4 rounded-[18px] bg-[#171B20] border border-white/10"><span className="text-[9px] text-[#19A7D8] font-bold">0{i + 1}</span><h5 className="mt-2 text-sm font-bold text-[#F4F1EA]">{h}</h5><p className="mt-2 text-xs leading-relaxed text-[#9FA7B0]">{c}</p></div>)}
      </div>
    </section>

    <section>
      <div className="flex items-center gap-3 mb-4"><span className="h-px w-8 bg-white/20" /><span className="text-[10px] uppercase tracking-[0.2em] text-[#9199A3]">06 · Final Logo & Additional Visuals</span></div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {['/assets/projects/logo-redesign-page-7.webp','/assets/projects/logo-redesign-page-8.webp','/assets/projects/logo-redesign-page-1.webp','/assets/projects/logo-redesign-page-3.webp'].map((img,i) => <div key={img} className="overflow-hidden rounded-[18px] border border-white/10 bg-[#171B20]"><img src={img} alt={`Logo redesign visual ${i + 1}`} className="w-full h-auto" / decoding="async"></div>)}
      </div>
    </section>

    <section className="p-5 sm:p-8 rounded-[22px] bg-[#111418] border border-[#19A7D8]/30">
      <div className="text-[9px] uppercase tracking-[0.18em] text-[#19A7D8]">Conclusion</div>
      <h4 className="mt-2 text-2xl sm:text-4xl font-black uppercase tracking-[-0.03em] text-[#F4F1EA]">A stronger global visual direction.</h4>
      <p className="mt-3 text-sm sm:text-base leading-relaxed text-[#A7ABB2]">The source presentation concludes that the redesigned 1.1.1.1 logo aims to communicate a secure, global and modern identity while connecting people through a trusted and secure network experience.</p>
    </section>
  </div>
);

interface ProjectModalProps {
  project: ProjectItem | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  // Lock body scroll and listen for Escape key
  useEffect(() => {
    if (!project) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.body.style.overflow = originalOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [project, onClose]);

  return (
    <AnimatePresence>
      {project && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-2 sm:p-5 md:p-8 select-none">
          {/* Backdrop overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={onClose}
            className="absolute inset-0 bg-[#111216]/85 backdrop-blur-xl cursor-pointer"
            aria-hidden="true"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
            className="relative w-full max-w-6xl max-h-[92vh] bg-[#171A1F] border border-[#F4F1EA]/20 rounded-[24px] sm:rounded-[36px] md:rounded-[44px] shadow-2xl overflow-y-auto overflow-x-hidden flex flex-col z-10 text-[#F4F1EA]"
          >
            {/* Modal Header */}
            <div className="sticky top-0 z-20 flex items-center justify-between px-4 sm:px-8 py-4 sm:py-6 bg-[#171A1F]/90 backdrop-blur-md border-b border-[#F4F1EA]/10">
              <div className="flex items-center gap-2.5 sm:gap-3">
                <span className="font-black text-lg sm:text-2xl text-[#1686A9]">
                  {project.number}
                </span>
                <span className="text-[11px] sm:text-sm uppercase tracking-widest text-[#F4F1EA]/60 font-light">
                  {project.category}
                </span>
              </div>

              {/* Close Button */}
              <button
                type="button"
                onClick={onClose}
                aria-label="Close project modal"
                className="w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center border border-[#F4F1EA]/20 bg-[#242930] hover:bg-[#2B3138] hover:border-[#1686A9]/60 text-[#F4F1EA] hover:text-[#F4F1EA] transition-all duration-200 cursor-pointer"
              >
                <svg
                  className="w-4 h-4 sm:w-5 sm:h-5 stroke-current"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>

            {/* Modal Body Content */}
            <div className="p-4 sm:p-8 md:p-10 space-y-6 sm:space-y-10">
              {project.id === 'vari-art' ? (
                <VariCaseStudy />
              ) : project.id === 'logo-redesign' ? (
                <LogoRedesignCaseStudy />
              ) : (
                <>
              {/* Title & Overview */}
              <div>
                <h3 className="text-xl sm:text-4xl md:text-5xl font-black uppercase tracking-tight text-[#F4F1EA] leading-tight mb-2.5 sm:mb-4">
                  {project.title}
                </h3>
                {project.shortDescription && (
                  <p className="text-xs sm:text-lg text-[#F4F1EA]/80 font-light leading-relaxed max-w-3xl">
                    {project.shortDescription}
                  </p>
                )}
              </div>

              {/* Tools Badges */}
              {project.tools && project.tools.length > 0 && (
                <div>
                  <h4 className="text-xs uppercase tracking-widest text-[#F4F1EA]/50 font-medium mb-3">
                    Tools Used
                  </h4>
                  <div className="flex flex-wrap gap-2.5">
                    {project.tools.map((tool, idx) => (
                      <span
                        key={idx}
                        className="px-3.5 py-1.5 rounded-full text-xs font-medium uppercase tracking-wider bg-[#242930] border border-[#F4F1EA]/15 text-[#F4F1EA]"
                      >
                        {tool}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Case Study Details */}
              {project.caseStudy && (
                <div className="space-y-8 pt-4 border-t border-white/10">
                  {/* Case Study Hero — intentionally separate from the homepage banner */}
                  {project.caseStudy.images?.[0] && (
                    <div className="overflow-hidden rounded-[22px] sm:rounded-[30px] bg-[#0F1115] border border-white/10">
                      <img
                        src={project.caseStudy.images[0]}
                        alt={`${project.title} identity presentation`}
                        className="w-full h-auto object-contain"
                      / decoding="async">
                    </div>
                  )}

                  <div className="grid grid-cols-1 lg:grid-cols-[1.45fr_0.8fr] gap-5 sm:gap-6">
                    {project.caseStudy.overview && (
                      <div className="p-5 sm:p-7 rounded-[20px] sm:rounded-[26px] bg-[#1D2229] border border-white/10">
                        <div className="flex items-center gap-3 mb-3">
                          <span className="h-px w-8 bg-[#19A7D8]" />
                          <h4 className="text-[10px] uppercase tracking-[0.2em] text-[#19A7D8] font-semibold">Project Overview</h4>
                        </div>
                        <p className="text-sm sm:text-base text-[#E2E5E9] font-light leading-relaxed">{project.caseStudy.overview}</p>
                      </div>
                    )}

                    {project.caseStudy.role && (
                      <div className="p-5 sm:p-7 rounded-[20px] sm:rounded-[26px] bg-[#1D2229] border border-white/10">
                        <div className="flex items-center gap-3 mb-3">
                          <span className="h-px w-8 bg-[#19A7D8]" />
                          <h4 className="text-[10px] uppercase tracking-[0.2em] text-[#19A7D8] font-semibold">My Role</h4>
                        </div>
                        <p className="text-sm sm:text-base text-[#E2E5E9] font-light leading-relaxed">{project.caseStudy.role}</p>
                      </div>
                    )}
                  </div>

                  {project.id === 'logo-design' && (
                    <div className="rounded-[20px] sm:rounded-[28px] border border-white/10 bg-[#101216] p-5 sm:p-8">
                      <div className="flex items-center gap-3 mb-5">
                        <span className="h-px w-8 bg-[#19A7D8]" />
                        <h4 className="text-[10px] uppercase tracking-[0.2em] text-[#19A7D8] font-semibold">Identity Direction</h4>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4">
                        <div className="rounded-2xl border border-white/10 bg-[#181B20] p-4">
                          <span className="text-[9px] uppercase tracking-[0.18em] text-[#7F8790]">01</span>
                          <h5 className="mt-2 text-sm font-bold uppercase text-[#F4F1EA]">Distinctive Mark</h5>
                          <p className="mt-2 text-xs leading-relaxed text-[#A7ABB2]">A brush-led symbol combines expressive lettering with a paint-tool gesture to connect creativity and production.</p>
                        </div>
                        <div className="rounded-2xl border border-white/10 bg-[#181B20] p-4">
                          <span className="text-[9px] uppercase tracking-[0.18em] text-[#7F8790]">02</span>
                          <h5 className="mt-2 text-sm font-bold uppercase text-[#F4F1EA]">Colour System</h5>
                          <p className="mt-2 text-xs leading-relaxed text-[#A7ABB2]">A restrained palette keeps the mark recognizable across identity boards, print pieces and presentation mockups.</p>
                        </div>
                        <div className="rounded-2xl border border-white/10 bg-[#181B20] p-4">
                          <span className="text-[9px] uppercase tracking-[0.18em] text-[#7F8790]">03</span>
                          <h5 className="mt-2 text-sm font-bold uppercase text-[#F4F1EA]">Brand Voice</h5>
                          <p className="mt-2 text-xs leading-relaxed text-[#A7ABB2]">“CREATE • CRAFT • PRINT” connects the identity to making, refinement and physical output.</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {project.id === 'vari-art' && (
                    <div className="rounded-[20px] sm:rounded-[28px] border border-white/10 bg-[#0F1115] p-5 sm:p-8">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-8 items-center">
                        <div>
                          <span className="text-[10px] uppercase tracking-[0.2em] text-[#19A7D8]">Core idea</span>
                          <h4 className="mt-2 text-2xl sm:text-4xl font-black uppercase tracking-[-0.035em] text-[#F4F1EA]">ONE WORD. TWO READINGS.</h4>
                          <p className="mt-4 text-sm sm:text-base leading-relaxed text-[#A7ABB2]">The identity uses the same stroke language to create two readings: <strong className="text-[#F4F1EA]">VARI</strong> for variation and <strong className="text-[#F4F1EA]">ART</strong> for creation. The shared R and transformed I make the transition happen without changing the visual language.</p>
                        </div>
                        <div className="grid grid-cols-2 gap-3 sm:gap-4">
                          <div className="rounded-2xl border border-white/10 bg-[#171A1F] p-4 sm:p-5 text-center">
                            <span className="block text-[9px] uppercase tracking-[0.2em] text-[#7F8790]">Read as</span>
                            <span className="block mt-2 text-xl sm:text-2xl font-black tracking-[0.2em] text-[#F4F1EA]">VARI</span>
                            <span className="block mt-1 text-[9px] uppercase tracking-[0.16em] text-[#19A7D8]">Variation</span>
                          </div>
                          <div className="rounded-2xl border border-white/10 bg-[#171A1F] p-4 sm:p-5 text-center">
                            <span className="block text-[9px] uppercase tracking-[0.2em] text-[#7F8790]">Discover</span>
                            <span className="block mt-2 text-xl sm:text-2xl font-black tracking-[0.2em] text-[#F4F1EA]">ART</span>
                            <span className="block mt-1 text-[9px] uppercase tracking-[0.16em] text-[#19A7D8]">Creation</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {project.caseStudy.process && project.caseStudy.process.length > 0 && (
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <span className="h-px w-8 bg-white/20" />
                        <h4 className="text-[10px] uppercase tracking-[0.2em] text-[#9199A3] font-medium">Design Process</h4>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                        {project.caseStudy.process.map((step, idx) => (
                          <div key={idx} className="p-4 sm:p-5 rounded-2xl bg-[#1D2229] border border-white/10">
                            <span className="text-xs font-bold text-[#19A7D8]">0{idx + 1}</span>
                            <p className="mt-3 text-sm text-[#E2E5E9] leading-relaxed">{step}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {project.caseStudy.deliverables && project.caseStudy.deliverables.length > 0 && (
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <span className="h-px w-8 bg-white/20" />
                        <h4 className="text-[10px] uppercase tracking-[0.2em] text-[#9199A3] font-medium">Deliverables</h4>
                      </div>
                      <div className="flex flex-wrap gap-2.5">
                        {project.caseStudy.deliverables.map((item, idx) => (
                          <span key={idx} className="px-3.5 py-2 rounded-full text-[10px] uppercase tracking-[0.14em] bg-[#1D2229] text-[#E2E5E9] border border-white/10">{item}</span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Additional Visuals */}
              {project.caseStudy?.images && project.caseStudy.images.length > 1 && (
                <div className="space-y-4 pt-6 border-t border-white/10">
                  <div className="flex items-center gap-3">
                    <span className="h-px w-8 bg-white/20" />
                    <h4 className="text-[10px] uppercase tracking-[0.2em] text-[#9199A3] font-medium">Additional Visuals</h4>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {project.caseStudy.images.slice(1).map((image, idx) => (
                      <div key={`${project.id}-gallery-${idx}`} className="overflow-hidden rounded-2xl bg-[#1A1D22] border border-white/10">
                        <img src={image} alt={`${project.title} additional visual ${idx + 1}`} loading="lazy" className="w-full h-auto object-cover" / decoding="async">
                      </div>
                    ))}
                  </div>
                </div>
              )}

                </>
              )}

              {/* Bottom Project CTA */}
              <div className="p-4 sm:p-8 rounded-2xl sm:rounded-3xl bg-[#1D2229] border border-[#1686A9]/25 flex flex-col sm:flex-row items-center justify-between gap-4 sm:gap-6 text-center sm:text-left">
                <div>
                  <h4 className="text-base sm:text-xl font-bold uppercase tracking-tight text-[#F4F1EA] mb-1">
                    Have a similar design project in mind?
                  </h4>
                  <p className="text-xs sm:text-sm text-[#F4F1EA]/60 font-light">
                    Let&apos;s collaborate to create impactful, memorable visuals.
                  </p>
                </div>
                <ContactButton />
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
