import React from 'react';
import { FadeIn } from '../common/FadeIn';
import { ContactButton } from '../common/ContactButton';

export const HeroSection: React.FC = () => {
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-[100dvh] flex flex-col overflow-hidden w-full bg-[#F1EFEA] text-[#121212]">
      <div className="absolute inset-0 pointer-events-none opacity-60 hero-paper-grid" />
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <span className="absolute left-5 top-32 text-[10px] tracking-[0.3em] text-[#121212]/50 rotate-90 origin-left">REG / 001</span>
        <span className="absolute right-5 bottom-28 text-[10px] tracking-[0.3em] text-[#121212]/45">CROP — MARK</span>
        <span className="absolute left-[4%] top-[31%] h-16 w-[3px] bg-[#121212]" />
        <span className="absolute right-[26%] top-[13%] h-8 w-[12px] bg-[#121212]" />
        <span className="absolute right-[8%] top-[27%] h-10 w-[18px] bg-[#121212]" />
        <span className="absolute left-[4%] top-[30%] h-[2px] w-14 bg-[#D8D000] rotate-[-4deg]" />
      </div>

      <FadeIn delay={0} y={-20} className="fixed inset-x-0 top-0 z-[100] w-full">
        <nav className="border-b border-black/10 bg-[#F1EFEA]/92 backdrop-blur-xl">
          <div className="flex min-h-[72px] items-center justify-between gap-5 max-w-[1320px] w-full mx-auto px-6 sm:px-8 lg:px-10 xl:px-0">
            <button type="button" onClick={() => { window.location.href = '/'; }} className="text-left group shrink-0">
              <span className="block text-sm sm:text-base font-black tracking-tight text-[#121212]">PRIYANSHU</span>
            </button>
            <div className="hidden md:flex items-center gap-7 text-[10px] lg:text-xs uppercase tracking-[0.14em] text-[#121212]">
              <a href="/projects#selected" className="hover:opacity-60 transition-opacity">Work</a>
              <button onClick={() => scrollToSection('about')} className="hover:opacity-60 transition-opacity">About</button>
              <button onClick={() => scrollToSection('services')} className="hover:opacity-60 transition-opacity">Services</button>
              <button onClick={() => scrollToSection('contact')} className="hover:opacity-60 transition-opacity">Contact</button>
            </div>
            <ContactButton label="Let's Talk ↗" className="!px-4 !py-2 !text-[10px] !bg-[#121212] !text-[#F1EFEA] !shadow-none !outline-none" />
          </div>
        </nav>
      </FadeIn>

      <div className="relative z-10 flex-1 grid min-w-0 lg:grid-cols-[minmax(0,0.92fr)_minmax(0,1.08fr)] gap-8 lg:gap-10 max-w-[1320px] w-full mx-auto px-6 sm:px-8 lg:px-10 xl:px-0 pt-[110px] pb-8 sm:pb-10 items-center">
        <div className="max-w-3xl relative z-20">
          <FadeIn delay={0.18} y={30}>
            <div className="relative inline-block">
              <span className="absolute -bottom-1 left-0 w-44 sm:w-56 h-4 bg-[#D8D000] -rotate-2" />
              <h1 className="hero-name relative mt-4 sm:mt-5 text-[clamp(3.3rem,7vw,7.4rem)] font-extrabold leading-[0.84] tracking-[-0.055em] text-[#121212]">PRIYANSHU</h1>
            </div>
          </FadeIn>

          <FadeIn delay={0.26} y={24}>
            <h2 className="mt-7 sm:mt-8 max-w-2xl text-[clamp(2rem,4vw,4rem)] font-black leading-[0.94] tracking-[-0.04em] text-[#121212]">
              Graphic designer with two years in the pressroom.
            </h2>
          </FadeIn>

          <FadeIn delay={0.34} y={20}>
            <p className="mt-6 max-w-xl text-sm sm:text-base lg:text-lg leading-relaxed text-[#3E3E3A]">
              Focused on brand identities, vector marks, editorial layouts and print-ready production. I turn ideas into clear visual systems — from concept and layout to the final printed piece.
            </p>
          </FadeIn>

          <FadeIn delay={0.42} y={20} className="mt-8 flex flex-wrap items-center gap-3">
            <button onClick={() => { window.location.href = '/projects'; }} className="px-5 py-3 rounded-full bg-[#121212] text-[#F1EFEA] text-xs sm:text-sm font-semibold uppercase tracking-wider hover:bg-[#D8D000] hover:text-[#121212] transition-colors">
              View selected work →
            </button>
            <a href="#contact" onClick={(e) => { e.preventDefault(); scrollToSection('contact'); }} className="px-5 py-3 rounded-full border border-black/30 text-[#121212] text-xs sm:text-sm uppercase tracking-wider hover:bg-[#121212] hover:text-[#F1EFEA] transition-colors">
              Download résumé ↓
            </a>
          </FadeIn>

          <FadeIn delay={0.5} y={20} className="mt-9 flex items-center gap-8">
            <div><strong className="block text-2xl sm:text-3xl font-black">2+</strong><span className="text-[9px] uppercase tracking-[0.2em]">Years in pressroom</span></div>
            <div className="h-10 w-px bg-black/15" />
            <div><strong className="block text-2xl sm:text-3xl font-black">50+</strong><span className="text-[9px] uppercase tracking-[0.2em]">Projects completed</span></div>
            <div className="h-10 w-px bg-black/15" />
            <div><strong className="block text-2xl sm:text-3xl font-black">10+</strong><span className="text-[9px] uppercase tracking-[0.2em]">Brands &amp; collaborations</span></div>
          </FadeIn>
        </div>

        <FadeIn delay={0.25} x={30} className="flex justify-center lg:justify-end relative">
          <div className="relative w-full max-w-[680px] min-w-0">
            <div className="absolute right-[7%] top-[2%] w-[31%] h-[58%] bg-[#D8D000] -z-10" />
            <div className="relative bg-[#F1EFEA] p-2 sm:p-3 shadow-[18px_22px_45px_rgba(0,0,0,0.14)] rotate-[1deg]">
              <img src="/assets/projects/priyanshu-hero-split.webp" alt="Priyanshu" className="hero-portrait-image w-full aspect-square object-cover object-center transition-transform duration-500 ease-out" / decoding="async">
              <div className="absolute -bottom-5 left-0 bg-[#121212] px-4 py-2 text-[9px] uppercase tracking-[0.22em] text-[#F1EFEA]">Print / Digital / Identity</div>
            </div>
            <div className="absolute -left-20 bottom-[22%] hidden xl:block text-[9px] uppercase tracking-[0.34em] leading-5 font-semibold">Creative<br/>Ideas<br/>Visuals<br/>Design</div>
            <div className="absolute -right-2 top-[45%] hidden xl:block text-[9px] uppercase tracking-[0.3em] leading-5 font-semibold">01<br/>—<br/>People<br/>Ideas<br/>Brands</div>
          </div>
        </FadeIn>
      </div>

      <div className="relative z-10 max-w-[1320px] w-full mx-auto px-6 sm:px-8 lg:px-10 xl:px-0 pb-5 flex items-center justify-between text-[9px] sm:text-[10px] uppercase tracking-[0.2em] text-[#66665F]">
        <span>Selected work / ideas to print</span>
        <span className="hidden sm:block">Scroll to explore ↓</span>
      </div>
    </section>
  );
};
