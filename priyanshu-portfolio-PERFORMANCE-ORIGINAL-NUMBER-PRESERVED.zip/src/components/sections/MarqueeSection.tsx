import React, { useEffect, useRef } from 'react';

const items = [
  { src: '/assets/projects/vari-art-banner.webp', label: 'VARI / ART — Conceptual Identity' },
  { src: '/assets/projects/tote-bag-mockup-set.webp', label: 'Tote Bag Design — Physical Application' },
  { src: '/assets/projects/logo-design-mockup.webp', label: 'Logo Design — Brand Identity' },
  { src: '/assets/projects/typography-showcase.webp', label: 'Typography — A Visual Study' },
];

export const MarqueeSection: React.FC = () => {
  const scrollerRef = useRef<HTMLDivElement>(null);
  const draggingRef = useRef(false);
  const dragStartXRef = useRef(0);
  const dragStartScrollRef = useRef(0);
  const didDragRef = useRef(false);
  const resumeTimerRef = useRef<number | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const loop = [...items, ...items, ...items];

  useEffect(() => {
    const scroller = scrollerRef.current;
    if (!scroller) return;

    const speed = 0.55;
    let lastTime = performance.now();

    // Start in the middle copy so the marquee can loop forever in either direction.
    const getSetWidth = () => scroller.scrollWidth / 3;

    const startAtMiddle = () => {
      if (scroller.scrollWidth > scroller.clientWidth) {
        scroller.scrollLeft = getSetWidth();
      }
    };

    startAtMiddle();
    window.addEventListener('resize', startAtMiddle);

    const tick = (time: number) => {
      const delta = Math.min(time - lastTime, 32);
      lastTime = time;

      if (!draggingRef.current && scroller.scrollWidth > scroller.clientWidth) {
        scroller.scrollLeft += speed * (delta / 16.67);

        // Normalize continuously inside the middle copy. This prevents the
        // marquee from ever reaching the physical end of the scroll container.
        const oneSetWidth = getSetWidth();
        if (scroller.scrollLeft >= oneSetWidth * 2) {
          scroller.scrollLeft -= oneSetWidth;
        } else if (scroller.scrollLeft <= 0) {
          scroller.scrollLeft += oneSetWidth;
        }
      }

      animationFrameRef.current = requestAnimationFrame(tick);
    };

    animationFrameRef.current = requestAnimationFrame(tick);

    return () => {
      window.removeEventListener('resize', startAtMiddle);
      if (animationFrameRef.current !== null) cancelAnimationFrame(animationFrameRef.current);
      if (resumeTimerRef.current !== null) window.clearTimeout(resumeTimerRef.current);
    };
  }, []);

  const pauseThenResume = () => {
    if (resumeTimerRef.current !== null) window.clearTimeout(resumeTimerRef.current);
    resumeTimerRef.current = window.setTimeout(() => {
      draggingRef.current = false;
    }, 900);
  };

  const handlePointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    const scroller = scrollerRef.current;
    if (!scroller) return;

    draggingRef.current = true;
    didDragRef.current = false;
    dragStartXRef.current = event.clientX;
    dragStartScrollRef.current = scroller.scrollLeft;
    scroller.setPointerCapture(event.pointerId);
    scroller.style.cursor = 'grabbing';
  };

  const handlePointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    const scroller = scrollerRef.current;
    if (!scroller || !draggingRef.current) return;

    const distance = event.clientX - dragStartXRef.current;
    if (Math.abs(distance) > 5) didDragRef.current = true;
    scroller.scrollLeft = dragStartScrollRef.current - distance;

    // Keep manual dragging inside the same infinite middle range.
    const oneSetWidth = scroller.scrollWidth / 3;
    if (scroller.scrollLeft >= oneSetWidth * 2) {
      scroller.scrollLeft -= oneSetWidth;
      dragStartScrollRef.current -= oneSetWidth;
    } else if (scroller.scrollLeft <= 0) {
      scroller.scrollLeft += oneSetWidth;
      dragStartScrollRef.current += oneSetWidth;
    }
  };

  const handlePointerUp = (event: React.PointerEvent<HTMLDivElement>) => {
    const scroller = scrollerRef.current;
    if (!scroller) return;

    if (scroller.hasPointerCapture(event.pointerId)) scroller.releasePointerCapture(event.pointerId);
    scroller.style.cursor = 'grab';
    pauseThenResume();
  };

  const handleClickCapture = (event: React.MouseEvent<HTMLDivElement>) => {
    if (didDragRef.current) {
      event.preventDefault();
      event.stopPropagation();
      didDragRef.current = false;
    }
  };

  return (
    <section className="w-full bg-[#121212] py-5 sm:py-7 overflow-hidden select-none" aria-label="Selected work preview">
      <div className="max-w-[1320px] mx-auto flex items-center gap-6 px-6 sm:px-8 lg:px-10 xl:px-0">
        <div className="hidden lg:block w-[105px] shrink-0 text-[#F1EFEA] text-[10px] uppercase tracking-[0.28em] leading-5">Selected<br/>Work</div>
        <div
          ref={scrollerRef}
          className="w-full overflow-x-auto scrollbar-none scroll-smooth"
          style={{ scrollbarWidth: 'none', cursor: 'grab', touchAction: 'pan-y' }}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          onClickCapture={handleClickCapture}
          aria-label="Drag selected work horizontally"
        >
          <div className="flex w-max gap-4 py-[1px]">
            {loop.map((item, index) => (
              <a key={`${item.src}-${index}`} href="/projects" className="group relative w-[240px] sm:w-[320px] md:w-[380px] h-[135px] sm:h-[175px] md:h-[205px] flex-shrink-0 overflow-hidden border border-white/15 bg-[#1a1a1a]" aria-label={`View ${item.label}`}>
                <img src={item.src} alt={item.label} loading="lazy" draggable={false} className="w-full h-full object-cover grayscale-[0.15] transition-transform duration-500 group-hover:scale-[1.04]" / decoding="async">
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent p-3 pt-10 pointer-events-none">
                  <span className="text-[9px] sm:text-[10px] uppercase tracking-[0.16em] text-white">{item.label}</span>
                </div>
              </a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
