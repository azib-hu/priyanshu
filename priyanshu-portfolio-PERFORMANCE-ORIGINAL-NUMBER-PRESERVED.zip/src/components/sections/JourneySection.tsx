import React from 'react';
import { FadeIn } from '../common/FadeIn';

export const JourneySection: React.FC = () => {
  return (
    <section
      id="journey"
      className="bg-[#F1EFEA] pt-16 sm:pt-24 md:pt-28 pb-12 sm:pb-16 md:pb-20 pl-11 pr-4 sm:px-8 md:px-10 relative z-10 select-none border-t border-[#121212]/10"
    >
      <div className="max-w-5xl mx-auto w-full">
        {/* Section Heading */}
        <div className="text-center mb-10 sm:mb-16">
          <FadeIn delay={0} y={30}>
            <span className="text-xs uppercase tracking-widest text-[#B8B000] font-medium block mb-2 sm:mb-3">
              Professional Journey
            </span>
            <h2 className="hero-heading font-black uppercase text-[clamp(2.2rem,8vw,100px)] leading-none tracking-tight mb-4 sm:mb-6">
              My Journey
            </h2>
          </FadeIn>
        </div>

        {/* Hero Experience Statement Card */}
        <FadeIn delay={0.15} y={30}>
          <div className="p-5 sm:p-12 md:p-14 rounded-[26px] sm:rounded-[40px] bg-[#E2DFD7] border border-[#121212]/12 shadow-2xl relative overflow-hidden text-center flex flex-col items-center">
            {/* Background Glow */}
            <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-80 h-80 bg-[#B8B000]/10 rounded-full blur-3xl pointer-events-none" />

            {/* Experience Metric Pills */}
            <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-5 sm:mb-6 max-w-full">
              <div className="inline-flex items-center gap-2 px-3 sm:px-5 py-1.5 sm:py-2 rounded-full bg-[#B8B000]/10 border border-[#B8B000]/35 text-[#756F00] text-[11px] sm:text-sm font-semibold uppercase tracking-widest text-center">
                <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-[#B8B000] animate-pulse" />
                1 Year of Experience in Graphic Design
              </div>
              <div className="inline-flex items-center gap-2 px-3 sm:px-5 py-1.5 sm:py-2 rounded-full bg-[#B8B000]/10 border border-[#B8B000]/35 text-[#756F00] text-[11px] sm:text-sm font-semibold uppercase tracking-widest text-center">
                <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-[#B8B000]" />
                Digital Printing Industry — 2 Years of Experience
              </div>
            </div>

            {/* Main Statement */}
            <h3 className="text-lg sm:text-3xl md:text-4xl font-medium uppercase tracking-tight text-[#121212] max-w-3xl leading-snug mb-4 sm:mb-6">
              &ldquo;I work across branding, social media, print and promotional graphics, with two years of hands-on experience in the pressroom and digital printing.&rdquo;
            </h3>

            <p className="text-xs sm:text-base text-[#4A4A45] font-light max-w-2xl leading-relaxed">
              I care about typography, composition, production details and whether the final piece works outside the screen — especially when it has to survive real print production.
            </p>
          </div>
        </FadeIn>

        {/* Core Focus Pillars */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 mt-6 sm:mt-10">
          {[
            {
              title: 'Branding & Identity',
              desc: 'Logo concepts, visual marks and identity systems developed with attention to how the final artwork will be used.',
            },
            {
              title: 'Social & Digital',
              desc: 'Campaign posts, promotional graphics and digital layouts built around clear hierarchy and quick communication.',
            },
            {
              title: 'Print & Production',
              desc: 'Brochures, posters, stationery and production files shaped by two years of hands-on digital printing work.',
            },
          ].map((item, idx) => (
            <FadeIn key={item.title} delay={0.2 + idx * 0.1} y={20}>
              <div className="p-5 sm:p-7 rounded-[22px] sm:rounded-[26px] bg-[#E2DFD7] border border-[#121212]/10 hover:border-[#121212]/25 transition-all duration-300 flex flex-col justify-between h-full">
                <div>
                  <span className="w-8 h-1 rounded-full bg-[#D8D000] block mb-4" />
                  <h4 className="text-base sm:text-lg font-bold uppercase tracking-tight text-[#121212] mb-2">
                    {item.title}
                  </h4>
                  <p className="text-xs sm:text-sm text-[#121212]/60 font-light leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
};
