import React, { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { projectsData } from '../../data/projectsData';
import type { ProjectItem, ProjectFilterCategory } from '../../types';
import { FadeIn } from '../common/FadeIn';
import { ProjectModal } from '../common/ProjectModal';

const FILTER_TABS: { label: string; value: ProjectFilterCategory }[] = [
  { label: 'ALL', value: 'all' },
  { label: 'BRANDING', value: 'branding' },
  { label: 'EDITORIAL', value: 'editorial' },
  { label: 'ADVERTISING', value: 'advertising' },
  { label: 'APPLICATIONS', value: 'applications' },
  { label: 'POSTERS', value: 'posters' },
  { label: 'EXPERIMENTAL', value: 'experimental' },
];

const SectionHeading = ({ index, title, count }: { index: string; title: string; count: number }) => (
  <div className="flex items-end justify-between gap-6 mb-8 sm:mb-12">
    <div>
      <span className="text-[10px] sm:text-xs uppercase tracking-[0.28em] text-[#D8D000] font-medium">{index}</span>
      <h3 className="mt-2 text-3xl sm:text-5xl md:text-6xl font-black uppercase tracking-[-0.04em] text-[#121212] leading-none">
        {title}
      </h3>
    </div>
    <span className="hidden sm:block text-[10px] uppercase tracking-[0.24em] text-[#121212]/35">
      {count} {count === 1 ? 'Project' : 'Projects'}
    </span>
  </div>
);

const ProjectButton = ({ project, onOpen }: { project: ProjectItem; onOpen: () => void }) => {
  const className = "inline-flex items-center gap-2 px-4 py-2.5 rounded-full border border-black/10 bg-black/[0.02] text-[#121212] text-[10px] sm:text-xs uppercase tracking-[0.14em] hover:border-[#D8D000]/70 hover:text-[#D8D000] hover:bg-[#D8D000]/[0.06] transition-all";

  if (project.liveUrl) {
    return (
      <a
        href={project.liveUrl}
        target="_blank"
        rel="noopener noreferrer"
        className={className}
        aria-label={`Open ${project.title} case study`}
      >
        View case study <span aria-hidden>↗</span>
      </a>
    );
  }

  return (
    <button type="button" onClick={onOpen} className={className}>
      View case study <span aria-hidden>↗</span>
    </button>
  );
};

const ProjectImage = ({ src, alt, className = '' }: { src: string; alt: string; className?: string }) => (
  <div className={`overflow-hidden rounded-[20px] sm:rounded-[28px] bg-[#E7E4DC] border border-black/10 ${className}`}>
    <img src={src} alt={alt} loading="lazy" className="w-full h-full object-cover transition-transform duration-700 hover:scale-[1.025]" / decoding="async">
  </div>
);

export const ProjectsSection: React.FC<{ standalone?: boolean }> = ({ standalone = false }) => {
  const [activeFilter, setActiveFilter] = useState<ProjectFilterCategory>('all');
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);

  const filteredProjects = useMemo(() => {
    if (activeFilter === 'all') return projectsData;
    return projectsData.filter((project) => project.filterCategory === activeFilter || project.tags?.includes(activeFilter));
  }, [activeFilter]);

  const groups = useMemo(() => {
    if (activeFilter !== 'all') return [{ key: 'filtered', index: '—', title: 'Filtered Work', items: filteredProjects }];
    return [
      { key: 'selected', index: '01', title: 'Selected Work', items: filteredProjects.filter((p) => p.portfolioSection === 'selected') },
      { key: 'smaller', index: '02', title: 'Smaller / Experimental Work', items: filteredProjects.filter((p) => p.portfolioSection === 'smaller') },
    ].filter((group) => group.items.length > 0);
  }, [activeFilter, filteredProjects]);

  return (
    <section id="projects" className={`relative z-10 bg-[#F1EFEA] px-5 sm:px-8 lg:px-12 ${standalone ? 'min-h-screen pt-6 sm:pt-10 pb-24' : '-mt-8 rounded-t-[32px] sm:rounded-t-[56px] pt-20 sm:pt-28 pb-24 sm:pb-36'}`}>
      <div className="max-w-6xl mx-auto min-w-0">
        {standalone && (
          <div className="flex items-center justify-between gap-4 pb-8 sm:pb-12 border-b border-black/10 mb-10 sm:mb-16">
            <a href="/" className="text-[10px] sm:text-xs uppercase tracking-[0.18em] text-[#4A4A45] hover:text-[#D8D000] transition-colors">
              ← Back to portfolio
            </a>
            <span className="text-[10px] sm:text-xs uppercase tracking-[0.18em] text-[#66665F]">Project Archive</span>
          </div>
        )}
        <div className="text-center mb-12 sm:mb-16">
          <FadeIn y={24}>
            <h2 className="mt-3 w-full max-w-full break-words text-[clamp(2.5rem,9vw,8rem)] font-black uppercase leading-[0.82] tracking-[-0.055em] text-[#121212]">Selected Work</h2>
          </FadeIn>
          <FadeIn delay={0.1} y={18}>
            <p className="mt-6 max-w-2xl mx-auto text-sm sm:text-base leading-relaxed text-[#4A4A45]">
              A curated selection of branding, editorial, print, advertising and experimental design work.
            </p>
          </FadeIn>
        </div>

        <FadeIn delay={0.15} y={15} className="mb-16 sm:mb-24">
          <div className="flex gap-2 overflow-x-auto pb-2 justify-start sm:justify-center scrollbar-none">
            {FILTER_TABS.map((tab) => {
              const active = activeFilter === tab.value;
              return (
                <button
                  key={tab.value}
                  type="button"
                  onClick={() => setActiveFilter(tab.value)}
                  className={`shrink-0 px-4 py-2 rounded-full border text-[10px] sm:text-xs uppercase tracking-[0.12em] transition-all ${
                    active
                      ? 'border-[#D8D000] bg-[#D8D000] text-[#F1EFEA] font-semibold'
                      : 'border-black/10 bg-black/[0.02] text-[#4A4A45] hover:text-[#121212] hover:border-black/20'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </FadeIn>

        <div className="space-y-24 sm:space-y-36">
          {groups.map((group) => (
            <div key={group.key} id={group.key === 'selected' ? 'selected' : group.key === 'smaller' ? 'smaller' : undefined}>
              <SectionHeading index={group.index} title={group.title} count={group.items.length} />

              {group.key === 'selected' || group.key === 'filtered' ? (
                <div>
                  {group.key === 'selected' ? (
                    <>
                      {group.items[0] && (
                        <motion.article
                          key={group.items[0].id}
                          initial={{ opacity: 0, y: 24 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.4 }}
                          className="border-t border-black/10 pt-7 sm:pt-9"
                        >
                          {(() => {
                            const project = group.items[0];
                            const secondaryImages = [project.col1Image2, project.col2Image].filter(Boolean);
                            if (project.showcaseImage) {
                              const href = project.imageLinkUrl || project.liveUrl;
                              return (
                                <div className="space-y-5">
                                  {href ? (
                                    <a
                                      href={href}
                                      target={href.startsWith('http') ? '_blank' : undefined}
                                      rel={href.startsWith('http') ? 'noopener noreferrer' : undefined}
                                      aria-label={`Open full ${project.title} image`}
                                      className="group block overflow-hidden rounded-[24px] sm:rounded-[34px] border border-black/10 bg-[#E7E4DC] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D8D000]"
                                    >
                                      <img src={project.showcaseImage} alt={`${project.title} showcase`} className="block w-full h-auto object-cover transition-transform duration-700 group-hover:scale-[1.01]" / decoding="async">
                                    </a>
                                  ) : (
                                    <button
                                      type="button"
                                      onClick={() => setSelectedProject(project)}
                                      aria-label={`Open ${project.title} case study`}
                                      className="group block w-full overflow-hidden rounded-[24px] sm:rounded-[34px] border border-black/10 bg-[#E7E4DC] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D8D000] text-left"
                                    >
                                      <img src={project.showcaseImage} alt={`${project.title} showcase`} className="block w-full h-auto object-cover transition-transform duration-700 group-hover:scale-[1.01]" / decoding="async">
                                    </button>
                                  )}
                                  {project.id === 'vari-art' ? null : (
                                    <div className="flex flex-wrap items-center justify-between gap-4 px-1">
                                      <div>
                                        <div className="flex items-center gap-3 mb-2">
                                          <span className="text-sm font-semibold text-[#D8D000]">{project.number}</span>
                                          <span className="h-px w-7 bg-black/20" />
                                          <span className="text-[9px] uppercase tracking-[0.2em] text-[#66665F]">{project.category}</span>
                                        </div>
                                        <p className="text-sm text-[#4A4A45] max-w-2xl">{project.shortDescription}</p>
                                      </div>
                                      <ProjectButton project={project} onOpen={() => setSelectedProject(project)} />
                                    </div>
                                  )}
                                </div>
                              );
                            }
                            return (
                              <div className="grid lg:grid-cols-[0.62fr_1.38fr] gap-8 lg:gap-12 items-center">
                                <div className="flex flex-col justify-between min-h-[360px] lg:min-h-[440px] py-1">
                                  <div>
                                    <div className="flex items-center gap-3 mb-5">
                                      <span className="text-sm sm:text-base font-semibold text-[#D8D000]">{project.number}</span>
                                      <span className="h-px w-8 bg-black/20" />
                                      <span className="text-[9px] sm:text-[10px] uppercase tracking-[0.2em] text-[#66665F]">{project.category}</span>
                                    </div>
                                    <h4 className="text-4xl sm:text-5xl lg:text-[4.2rem] font-black uppercase tracking-[-0.05em] leading-[0.88] text-[#121212] max-w-xl">{project.title}</h4>
                                    <p className="mt-6 text-sm sm:text-base leading-relaxed text-[#4A4A45] max-w-md">{project.shortDescription}</p>
                                  </div>
                                  <div className="mt-8">
                                    <div className="flex flex-wrap gap-2 mb-6">
                                      {project.tools?.slice(0, 2).map((tool) => (
                                        <span key={tool} className="px-3 py-1.5 rounded-full border border-black/10 text-[9px] uppercase tracking-[0.12em] text-[#4A4A45]">{tool}</span>
                                      ))}
                                    </div>
                                    <ProjectButton project={project} onOpen={() => setSelectedProject(project)} />
                                  </div>
                                </div>
                                <div className="grid grid-cols-[1.55fr_0.55fr] gap-3 sm:gap-4 min-h-[360px] sm:min-h-[440px]">
                                  <ProjectImage src={project.col1Image1} alt={`${project.title} main presentation`} className="min-h-[360px] sm:min-h-[440px] rounded-[22px] sm:rounded-[28px]" />
                                  <div className="grid grid-rows-2 gap-3 sm:gap-4">
                                    {secondaryImages.slice(0, 2).map((src, imageIndex) => (
                                      <ProjectImage key={`${project.id}-secondary-${imageIndex}`} src={src} alt={`${project.title} detail ${imageIndex + 1}`} className="min-h-[170px] sm:min-h-[210px] rounded-[18px] sm:rounded-[22px]" />
                                    ))}
                                  </div>
                                </div>
                              </div>
                            );
                          })()}
                        </motion.article>
                      )}

                      <div className="grid md:grid-cols-3 gap-6 sm:gap-8 mt-12 sm:mt-16">
                        {group.items.slice(1, 4).map((project, index) => (
                          <motion.article
                            key={project.id}
                            initial={{ opacity: 0, y: 24 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.35, delay: index * 0.05 }}
                            className="group"
                          >
                            {project.id === 'architectural-digest' ? (
                              <a
                                href="https://heyzine.com/flip-book/8bef9d29a2.html#page/1"
                                target="_blank"
                                rel="noopener noreferrer"
                                className="block w-full text-left"
                                aria-label="Open Architectural Digest — Mountain Homes on Heyzine"
                              >
                                <div className="overflow-hidden rounded-[22px] sm:rounded-[28px] bg-[#E7E4DC] border border-black/10 aspect-[16/10]">
                                  <img src={project.col1Image1} alt={`${project.title} preview`} loading="lazy" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.025]" / decoding="async">
                                </div>
                                <div className="pt-5 sm:pt-6">
                                  <div className="flex items-center gap-3 mb-3">
                                    <span className="text-sm font-semibold text-[#D8D000]">{project.number}</span>
                                    <span className="h-px w-7 bg-black/20" />
                                    <span className="text-[9px] sm:text-[10px] uppercase tracking-[0.2em] text-[#66665F]">{project.category}</span>
                                  </div>
                                  <div className="flex items-start justify-between gap-4">
                                    <h4 className="text-xl sm:text-2xl font-black uppercase tracking-[-0.035em] leading-[0.95] text-[#121212]">{project.title}</h4>
                                    <span className="text-[#121212] text-lg leading-none transition-transform group-hover:translate-x-1 group-hover:-translate-y-1">↗</span>
                                  </div>
                                  <p className="mt-3 text-sm leading-relaxed text-[#4A4A45] line-clamp-2">{project.shortDescription}</p>
                                  <div className="mt-4 flex flex-wrap gap-2">
                                    {project.tools?.slice(0, 2).map((tool) => (
                                      <span key={tool} className="px-2.5 py-1.5 rounded-full border border-black/10 text-[9px] uppercase tracking-[0.12em] text-[#66665F]">{tool}</span>
                                    ))}
                                  </div>
                                </div>
                              </a>
                            ) : (
                              <button type="button" onClick={() => setSelectedProject(project)} className="block w-full text-left">
                                <div className="overflow-hidden rounded-[22px] sm:rounded-[28px] bg-[#E7E4DC] border border-black/10 aspect-[16/10]">
                                  <img src={project.col1Image1} alt={`${project.title} preview`} loading="lazy" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.025]" / decoding="async">
                                </div>
                                <div className="pt-5 sm:pt-6">
                                  <div className="flex items-center gap-3 mb-3">
                                    <span className="text-sm font-semibold text-[#D8D000]">{project.number}</span>
                                    <span className="h-px w-7 bg-black/20" />
                                    <span className="text-[9px] sm:text-[10px] uppercase tracking-[0.2em] text-[#66665F]">{project.category}</span>
                                  </div>
                                  <div className="flex items-start justify-between gap-4">
                                    <h4 className="text-xl sm:text-2xl font-black uppercase tracking-[-0.035em] leading-[0.95] text-[#121212]">{project.title}</h4>
                                    <span className="text-[#121212] text-lg leading-none transition-transform group-hover:translate-x-1 group-hover:-translate-y-1">↗</span>
                                  </div>
                                  <p className="mt-3 text-sm leading-relaxed text-[#4A4A45] line-clamp-2">{project.shortDescription}</p>
                                  <div className="mt-4 flex flex-wrap gap-2">
                                    {project.tools?.slice(0, 2).map((tool) => (
                                      <span key={tool} className="px-2.5 py-1.5 rounded-full border border-black/10 text-[9px] uppercase tracking-[0.12em] text-[#66665F]">{tool}</span>
                                    ))}
                                  </div>
                                </div>
                              </button>
                            )}
                          </motion.article>
                        ))}
                      </div>

                      <div className="space-y-12 sm:space-y-16 mt-14 sm:mt-20">
                        {group.items.slice(4).map((project, index) => (
                          <motion.article
                            key={project.id}
                            initial={{ opacity: 0, y: 24 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.35, delay: index * 0.04 }}
                            className="group border-t border-black/10 pt-7 sm:pt-9"
                          >
                            <div className="grid md:grid-cols-2 gap-6 sm:gap-8 items-start">
                              <div className="overflow-hidden rounded-[22px] sm:rounded-[28px] bg-[#E7E4DC] border border-black/10 aspect-[16/10]">
                                <img src={project.col1Image1} alt={`${project.title} preview`} loading="lazy" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.025]" / decoding="async">
                              </div>
                              <div className="flex flex-col justify-center min-h-full py-1 sm:py-4">
                                <div className="flex items-center gap-3 mb-4">
                                  <span className="text-sm font-semibold text-[#D8D000]">{project.number}</span>
                                  <span className="h-px w-8 bg-black/20" />
                                  <span className="text-[9px] sm:text-[10px] uppercase tracking-[0.2em] text-[#66665F]">{project.category}</span>
                                </div>
                                <h4 className="text-3xl sm:text-4xl font-black uppercase tracking-[-0.04em] leading-[0.92] text-[#121212]">{project.title}</h4>
                                <p className="mt-4 text-sm leading-relaxed text-[#4A4A45] max-w-xl">{project.shortDescription}</p>
                                <div className="mt-6 flex flex-wrap items-center gap-2">
                                  {project.tools?.slice(0, 2).map((tool) => (
                                    <span key={tool} className="px-2.5 py-1.5 rounded-full border border-black/10 text-[9px] uppercase tracking-[0.12em] text-[#66665F]">{tool}</span>
                                  ))}
                                </div>
                                <div className="mt-6"><ProjectButton project={project} onOpen={() => setSelectedProject(project)} /></div>
                              </div>
                            </div>
                          </motion.article>
                        ))}
                      </div>
                    </>
                  ) : (
                    <div className="space-y-12 sm:space-y-16">
                      <AnimatePresence mode="popLayout">
                        {group.items.map((project, index) => (
                          <motion.article
                            key={project.id}
                            layout
                            initial={{ opacity: 0, y: 24 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 16 }}
                            transition={{ duration: 0.35, delay: index * 0.035 }}
                            className="group border-t border-black/10 pt-7 sm:pt-9"
                          >
                            {project.showcaseImage ? (
                              <div className="space-y-5">
                                {project.imageLinkUrl || project.liveUrl ? (
                                  <a
                                    href={project.imageLinkUrl || project.liveUrl}
                                    target={(project.imageLinkUrl || project.liveUrl || '').startsWith('http') ? '_blank' : undefined}
                                    rel={(project.imageLinkUrl || project.liveUrl || '').startsWith('http') ? 'noopener noreferrer' : undefined}
                                    aria-label={`Open ${project.title}`}
                                    className="group block overflow-hidden rounded-[24px] sm:rounded-[34px] bg-[#E7E4DC] border border-black/10 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D8D000]"
                                  >
                                    <img src={project.showcaseImage} alt={`${project.title} showcase`} className="w-full h-auto block transition-transform duration-700 group-hover:scale-[1.01]" / decoding="async">
                                  </a>
                                ) : (
                                  <button
                                    type="button"
                                    onClick={() => setSelectedProject(project)}
                                    aria-label={`Open ${project.title} case study`}
                                    className="group block w-full overflow-hidden rounded-[24px] sm:rounded-[34px] bg-[#E7E4DC] border border-black/10 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D8D000] text-left"
                                  >
                                    <img src={project.showcaseImage} alt={`${project.title} showcase`} className="w-full h-auto block transition-transform duration-700 group-hover:scale-[1.01]" / decoding="async">
                                  </button>
                                )}
                                <div className="flex flex-wrap items-center justify-between gap-4 px-1">
                                  <div>
                                    <div className="flex items-center gap-3 mb-2"><span className="text-sm font-semibold text-[#D8D000]">{project.number}</span><span className="h-px w-8 bg-black/20" /><span className="text-[9px] sm:text-[10px] uppercase tracking-[0.2em] text-[#66665F]">{project.category}</span></div>
                                    <p className="text-sm leading-relaxed text-[#4A4A45] max-w-2xl">{project.shortDescription}</p>
                                  </div>
                                  <ProjectButton project={project} onOpen={() => setSelectedProject(project)} />
                                </div>
                              </div>
                            ) : (
                              <div className="grid md:grid-cols-2 gap-6 sm:gap-8 items-start">
                                <div className="overflow-hidden rounded-[22px] sm:rounded-[28px] bg-[#E7E4DC] border border-black/10 aspect-[16/10]">
                                  <img src={project.col1Image1} alt={`${project.title} preview`} loading="lazy" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.025]" / decoding="async">
                                </div>
                                <div className="flex flex-col justify-center py-1 sm:py-4">
                                  <div className="flex items-center gap-3 mb-4"><span className="text-sm font-semibold text-[#D8D000]">{project.number}</span><span className="h-px w-8 bg-black/20" /><span className="text-[9px] sm:text-[10px] uppercase tracking-[0.2em] text-[#66665F]">{project.category}</span></div>
                                  <h4 className="text-3xl sm:text-4xl font-black uppercase tracking-[-0.04em] leading-[0.92] text-[#121212]">{project.title}</h4>
                                  <p className="mt-4 text-sm leading-relaxed text-[#4A4A45] max-w-xl">{project.shortDescription}</p>
                                  <div className="mt-6"><ProjectButton project={project} onOpen={() => setSelectedProject(project)} /></div>
                                </div>
                              </div>
                            )}
                          </motion.article>
                        ))}
                      </AnimatePresence>
                    </div>
                  )}
                </div>
              ) : (
                <div className="grid md:grid-cols-2 gap-6 sm:gap-8">
                  <AnimatePresence mode="popLayout">
                    {group.items.map((project, index) => (
                      <motion.article
                        key={project.id}
                        layout
                        initial={{ opacity: 0, y: 24 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 16 }}
                        transition={{ duration: 0.35, delay: index * 0.035 }}
                        className="group border border-black/10 rounded-[24px] sm:rounded-[32px] bg-[#E9E6DE] p-3 sm:p-4 hover:border-black/20 transition-colors"
                      >
                        {project.liveUrl ? (
                          <a
                            href={project.liveUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block w-full text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D8D000] rounded-[20px]"
                            aria-label={`Open ${project.title} case study`}
                          >
                            <ProjectImage src={project.col2Image} alt={project.title} className="aspect-[1.35/1]" />
                            <div className="px-1 sm:px-2 pt-5 pb-2">
                              <div className="flex items-center gap-2 mb-2">
                                <span className="text-xs font-semibold text-[#D8D000]">{project.number}</span>
                                <span className="text-[9px] uppercase tracking-[0.18em] text-[#66665F]">{project.category}</span>
                              </div>
                              <h4 className="text-xl sm:text-2xl font-bold uppercase tracking-tight text-[#121212]">{project.title}</h4>
                              <p className="mt-2 text-xs sm:text-sm leading-relaxed text-[#66665F] line-clamp-2">{project.shortDescription}</p>
                              <span className="inline-block mt-4 text-[10px] uppercase tracking-[0.16em] text-[#D8D000]">View case study ↗</span>
                            </div>
                          </a>
                        ) : (
                          <button type="button" onClick={() => setSelectedProject(project)} className="block w-full text-left">
                            <ProjectImage src={project.col2Image} alt={project.title} className="aspect-[1.35/1]" />
                            <div className="px-1 sm:px-2 pt-5 pb-2">
                              <div className="flex items-center gap-2 mb-2">
                                <span className="text-xs font-semibold text-[#D8D000]">{project.number}</span>
                                <span className="text-[9px] uppercase tracking-[0.18em] text-[#66665F]">{project.category}</span>
                              </div>
                              <h4 className="text-xl sm:text-2xl font-bold uppercase tracking-tight text-[#121212]">{project.title}</h4>
                              <p className="mt-2 text-xs sm:text-sm leading-relaxed text-[#66665F] line-clamp-2">{project.shortDescription}</p>
                              <span className="inline-block mt-4 text-[10px] uppercase tracking-[0.16em] text-[#D8D000]">View case study ↗</span>
                            </div>
                          </button>
                        )}
                      </motion.article>
                    ))}
                  </AnimatePresence>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <ProjectModal project={selectedProject} onClose={() => setSelectedProject(null)} />
    </section>
  );
};
