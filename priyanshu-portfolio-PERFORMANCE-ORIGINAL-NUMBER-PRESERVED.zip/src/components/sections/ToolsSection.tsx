import React from 'react';
import { FadeIn } from '../common/FadeIn';

interface ToolItem {
  name: string;
  abbr: string;
  category: string;
  description: string;
  accentColor: string;
  glowColor: string;
}

const toolsData: ToolItem[] = [
  {
    name: 'Adobe Photoshop',
    abbr: 'Ps',
    category: 'Raster & Photo Manipulation',
    description: 'Image retouching, background removal, photo compositing, color grading, and dynamic social media visuals.',
    accentColor: '#31A8FF',
    glowColor: 'rgba(49, 168, 255, 0.25)',
  },
  {
    name: 'Adobe Illustrator',
    abbr: 'Ai',
    category: 'Vector & Identity Design',
    description: 'Logo creation, brand marks, vector illustrations, custom typography pairings, and scalable design systems.',
    accentColor: '#FF9A00',
    glowColor: 'rgba(255, 154, 0, 0.25)',
  },
  {
    name: 'CorelDRAW',
    abbr: 'CDR',
    category: 'Vector & Commercial Print',
    description: 'Large-format banners, commercial marketing collateral, signage design, and production vector artwork.',
    accentColor: '#60BE1C',
    glowColor: 'rgba(96, 190, 28, 0.25)',
  },
  {
    name: 'Adobe InDesign',
    abbr: 'Id',
    category: 'Editorial & Layout',
    description: 'Brochures, business cards, multi-page catalogues, print typesetting, and print-ready prepress formatting.',
    accentColor: '#FF3366',
    glowColor: 'rgba(255, 51, 102, 0.25)',
  },
];

export const ToolsSection: React.FC = () => {
  return (
    <section
      id="tools"
      className="bg-[#F1EFEA] py-16 sm:py-28 md:py-32 pl-11 pr-4 sm:px-8 md:px-10 relative z-10 select-none"
    >
      <div className="max-w-6xl mx-auto w-full">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-12 sm:mb-20">
          <FadeIn delay={0} y={30}>
            <h2 className="hero-heading font-black uppercase text-[clamp(2.2rem,8vw,100px)] leading-none tracking-tight mb-4 sm:mb-6">
              Tools I Use
            </h2>
          </FadeIn>
          <FadeIn delay={0.15} y={20}>
            <p className="text-xs sm:text-base md:text-lg text-[#121212]/70 font-light max-w-2xl leading-relaxed">
              Essential professional software utilized daily for visual branding, social collateral, photo editing, and print-ready deliverables.
            </p>
          </FadeIn>
        </div>

        {/* 4 Tool Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {toolsData.map((tool, idx) => (
            <FadeIn key={tool.name} delay={idx * 0.1} y={30} className="h-full">
              <div
                className="group h-full p-5 sm:p-7 rounded-[22px] sm:rounded-[32px] bg-[#E9E6DE] border border-[#121212]/10 hover:border-[#B8B000]/50 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_10px_30px_rgba(0,0,0,0.5)] cursor-default"
                style={{
                  transition: 'all 0.3s cubic-bezier(0.25, 0.1, 0.25, 1)',
                }}
              >
                <div>
                  {/* Top row: Badge & Category */}
                  <div className="flex items-center justify-between mb-6">
                    <span
                      className="w-12 h-12 rounded-2xl flex items-center justify-center font-black text-base select-none transition-transform duration-300 group-hover:scale-110 shadow-md"
                      style={{
                        backgroundColor: `${tool.accentColor}18`,
                        color: tool.accentColor,
                        border: `1px solid ${tool.accentColor}40`,
                      }}
                    >
                      {tool.abbr}
                    </span>
                    <span className="text-[11px] uppercase tracking-wider text-[#121212]/40 font-light">
                      Software
                    </span>
                  </div>

                  {/* Tool Name & Category */}
                  <h3 className="text-xl sm:text-2xl font-bold uppercase tracking-tight text-[#121212] mb-1.5 group-hover:text-[#121212] transition-colors">
                    {tool.name}
                  </h3>
                  <p
                    className="text-xs font-medium uppercase tracking-wider mb-4"
                    style={{ color: tool.accentColor }}
                  >
                    {tool.category}
                  </p>
                </div>

                {/* Description */}
                <p className="text-xs sm:text-sm text-[#121212]/60 font-light leading-relaxed pt-4 border-t border-[#121212]/10">
                  {tool.description}
                </p>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
};
