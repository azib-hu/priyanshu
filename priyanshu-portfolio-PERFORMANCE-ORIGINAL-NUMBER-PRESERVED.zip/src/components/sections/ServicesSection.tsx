import React from 'react';
import { servicesData } from '../../data/servicesData';
import { FadeIn } from '../common/FadeIn';

export const ServicesSection: React.FC = () => {
  return (
    <section
      id="services"
      className="bg-[#F1EFEA] text-[#121212] px-5 sm:px-8 lg:px-12 py-16 sm:py-20 md:py-24 relative z-0"
    >
      <div className="max-w-6xl mx-auto w-full">
        <FadeIn delay={0} y={24}>
          <div className="flex items-end justify-between gap-6 mb-8 sm:mb-12">
            <div>
              <h2 className="font-black uppercase text-[clamp(2.6rem,7vw,6rem)] leading-[0.85] tracking-[-0.05em]">
                Services
              </h2>
            </div>
          </div>
        </FadeIn>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 border-t border-black/10">
          {servicesData.map((service, index) => (
            <FadeIn
              key={service.name}
              delay={index * 0.05}
              y={18}
              className="border-b border-black/10 sm:[&:nth-child(odd)]:border-r lg:[&:nth-child(3n+1)]:border-r lg:[&:nth-child(3n+2)]:border-r"
            >
              <div className="group min-h-[150px] sm:min-h-[165px] p-5 sm:p-6 md:p-7 flex flex-col justify-between hover:bg-black/40 transition-colors">
                <div className="flex items-start justify-between gap-4">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#D8D000] shadow-[0_0_14px_rgba(25,167,216,0.45)] mt-1.5" />
                  <span className="text-[9px] uppercase tracking-[0.18em] text-[#66665F]">Service</span>
                </div>
                <div className="mt-7">
                  <h3 className="font-bold uppercase text-base sm:text-lg tracking-tight text-[#121212] group-hover:text-[#D8D000] transition-colors">
                    {service.name}
                  </h3>
                  <p className="mt-1.5 text-[11px] sm:text-xs leading-relaxed text-[#4A4A45] max-w-sm">
                    {service.description}
                  </p>
                </div>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
};
