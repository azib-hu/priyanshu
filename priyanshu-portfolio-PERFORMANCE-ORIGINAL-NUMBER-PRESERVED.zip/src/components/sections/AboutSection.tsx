import React from 'react';
import { FadeIn } from '../common/FadeIn';
import { AnimatedText } from '../common/AnimatedText';

export const AboutSection: React.FC = () => {
  return (
    <section
      id="about"
      className="min-h-screen relative flex flex-col justify-center items-center pl-11 pr-4 sm:px-8 md:px-10 py-16 sm:py-28 md:py-32 overflow-hidden bg-[#F1EFEA] select-none"
    >
      {/* Main Content */}
      <div className="flex flex-col items-center justify-center text-center z-10 max-w-4xl mx-auto w-full">
        <FadeIn delay={0} y={30}>
          <h2 className="hero-heading font-black uppercase leading-none tracking-tight text-center text-[clamp(2.2rem,8vw,130px)] mb-6 sm:mb-8">
            About Me
          </h2>
        </FadeIn>

        {/* Experience Pills */}
        <FadeIn delay={0.1} y={20}>
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-2.5 mb-6 sm:mb-10 max-w-full">
            <div className="inline-flex items-center gap-2 px-3 sm:px-4 py-1.5 rounded-full bg-[#E2DFD7] border border-[#B8B000]/30 text-[11px] sm:text-xs uppercase tracking-wider sm:tracking-widest text-[#121212]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#B8B000]" />
              1 Year Graphic Design Experience
            </div>
            <div className="inline-flex items-center gap-2 px-3 sm:px-4 py-1.5 rounded-full bg-[#E2DFD7] border border-[#B8B000]/30 text-[11px] sm:text-xs uppercase tracking-wider sm:tracking-widest text-[#121212]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#B8B000]" />
              Digital Printing Industry — 2 Years of Experience
            </div>
          </div>
        </FadeIn>

        {/* Exact Bio Copy with Character Opacity Reveal */}
        <div className="flex flex-col items-center w-full">
          <AnimatedText
            text="I'm Priyanshu, a graphic designer with two years in the pressroom and hands-on experience across branding, editorial layouts, posters and print production. I work in Photoshop, Illustrator, CorelDRAW and InDesign, taking work from rough direction and typography through artwork, prepress and the final printed piece."
            className="text-[#121212] font-medium text-center leading-relaxed max-w-[720px] text-[clamp(0.88rem,1.7vw,1.3rem)]"
          />

          {/* Key Areas Hierarchy Grid */}
          <FadeIn delay={0.25} y={20} className="w-full mt-8 sm:mt-12">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 sm:gap-4 max-w-3xl mx-auto text-left w-full">
              <div className="p-4 sm:p-5 rounded-2xl bg-[#E9E6DE]/80 border border-[#121212]/10 hover:border-[#B8B000]/30 transition-colors">
                <span className="text-xs text-[#B8B000] font-semibold uppercase tracking-wider block mb-1">
                  Experience
                </span>
                <p className="text-xs sm:text-sm text-[#121212] font-medium">
                  Two years of hands-on print and production experience
                </p>
              </div>

              <div className="p-4 sm:p-5 rounded-2xl bg-[#E9E6DE]/80 border border-[#121212]/10 hover:border-[#B8B000]/30 transition-colors">
                <span className="text-xs text-[#B8B000] font-semibold uppercase tracking-wider block mb-1">
                  Core Tools
                </span>
                <p className="text-xs sm:text-sm text-[#121212] font-medium">
                  Photoshop, Illustrator, CorelDRAW, InDesign
                </p>
              </div>

              <div className="p-4 sm:p-5 rounded-2xl bg-[#E9E6DE]/80 border border-[#121212]/10 hover:border-[#B8B000]/30 transition-colors">
                <span className="text-xs text-[#B8B000] font-semibold uppercase tracking-wider block mb-1">
                  Disciplines
                </span>
                <p className="text-xs sm:text-sm text-[#121212] font-medium">
                  Branding, Social Media, Posters &amp; Print
                </p>
              </div>
            </div>
          </FadeIn>
        </div>
      </div>
    </section>
  );
};
