import React from 'react';
import { motion } from 'framer-motion';
import { FadeIn } from '../common/FadeIn';
import { WhatsAppIcon, LinkedInIcon } from '../common/SocialIcons';
import { LINKEDIN_URL } from '../common/FixedSocialBar';

export const ContactSection: React.FC = () => {
  return (
    <section
      id="contact"
      className="bg-[#F1EFEA] pt-12 sm:pt-16 md:pt-20 pb-12 sm:pb-16 md:pb-20 pl-11 pr-4 sm:px-8 md:px-10 relative z-10 select-none border-t border-[#121212]/10 overflow-hidden"
    >
      {/* Background Soft Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[420px] h-[420px] bg-gradient-to-br from-[#D8D000]/10 via-[#B8B000]/10 to-transparent rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-4xl mx-auto text-center flex flex-col items-center relative z-10">
        {/* Eyebrow & Headline */}
        <FadeIn delay={0} y={25}>
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#E9EEF2] border border-[#B8B000]/30 text-[#B8B000] text-xs uppercase tracking-widest font-medium mb-4">
            <span className="w-1.5 h-1.5 rounded-full bg-[#B8B000] animate-pulse" />
            Available for Design Projects &amp; Collaborations
          </div>
          <h2 className="hero-heading font-black uppercase text-[clamp(2.2rem,6.5vw,75px)] tracking-tight leading-none mb-3 sm:mb-4">
            Let&apos;s Create Something Great
          </h2>
        </FadeIn>

        {/* Short Statement */}
        <FadeIn delay={0.12} y={20}>
          <p className="text-xs sm:text-base md:text-lg text-[#121212]/70 font-light max-w-xl mx-auto leading-relaxed mb-8 sm:mb-10">
            Have a visual identity, branding, or print design project in mind? Reach out directly through either channel below.
          </p>
        </FadeIn>

        {/* Direct Channel Cards (WhatsApp & LinkedIn) */}
        <FadeIn delay={0.22} y={20} className="w-full">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 sm:gap-4 max-w-xl w-full mx-auto">
            {/* WhatsApp Card */}
            <motion.a
              href="https://wa.me/919627616226"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ y: -3, scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              transition={{ duration: 0.2 }}
              aria-label="Chat directly on WhatsApp (+234 702 046 6988)"
              className="group flex items-center justify-between p-4 sm:p-5 rounded-2xl bg-[#E9E6DE] border border-[#121212]/10 hover:border-[#25D366]/60 hover:bg-[#DAD7CE] transition-all duration-300 shadow-lg cursor-pointer text-left"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-[#25D366]/15 border border-[#25D366]/30 flex items-center justify-center text-[#25D366] group-hover:scale-110 transition-transform duration-200 flex-shrink-0">
                  <WhatsAppIcon className="w-5 h-5 fill-current" />
                </div>
                <div>
                  <span className="text-xs sm:text-sm font-semibold uppercase tracking-wider text-[#121212] group-hover:text-[#121212] block">
                    WhatsApp
                  </span>
                  <span className="text-[11px] text-[#121212]/50 font-light block">
                    +234 702 046 6988
                  </span>
                </div>
              </div>
              <span className="text-sm text-[#121212]/40 group-hover:text-[#121212] group-hover:translate-x-1 transition-all flex-shrink-0 ml-2">
                &rarr;
              </span>
            </motion.a>

            {/* LinkedIn Card */}
            <motion.a
              href={LINKEDIN_URL}
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ y: -3, scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              transition={{ duration: 0.2 }}
              aria-label="Connect on LinkedIn"
              className="group flex items-center justify-between p-4 sm:p-5 rounded-2xl bg-[#E9E6DE] border border-[#121212]/10 hover:border-[#B8B000]/60 hover:bg-[#DAD7CE] transition-all duration-300 shadow-lg cursor-pointer text-left"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-[#B8B000]/15 border border-[#B8B000]/30 flex items-center justify-center text-[#B8B000] group-hover:scale-110 transition-transform duration-200 flex-shrink-0">
                  <LinkedInIcon className="w-5 h-5 fill-current" />
                </div>
                <div>
                  <span className="text-xs sm:text-sm font-semibold uppercase tracking-wider text-[#121212] group-hover:text-[#121212] block">
                    LinkedIn
                  </span>
                  <span className="text-[11px] text-[#121212]/50 font-light block">
                    Professional Network
                  </span>
                </div>
              </div>
              <span className="text-sm text-[#121212]/40 group-hover:text-[#121212] group-hover:translate-x-1 transition-all flex-shrink-0 ml-2">
                &rarr;
              </span>
            </motion.a>
          </div>
        </FadeIn>

        {/* Clean Footer Bar */}
        <div className="mt-12 sm:mt-16 pt-6 sm:pt-8 border-t border-[#121212]/10 w-full flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <p className="text-[#121212]/40 text-xs uppercase tracking-wider font-light">
            &copy; {new Date().getFullYear()} Priyanshu &bull; Graphic Designer
          </p>
          <button
            type="button"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="text-[11px] uppercase tracking-widest text-[#121212]/50 hover:text-[#B8B000] transition-colors duration-200 cursor-pointer flex items-center gap-1.5"
          >
            <span>Back to Top</span>
            <span>&uarr;</span>
          </button>
        </div>
      </div>
    </section>
  );
};
