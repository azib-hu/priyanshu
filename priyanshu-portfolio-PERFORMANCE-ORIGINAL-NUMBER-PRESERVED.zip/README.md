# Priyanshu Portfolio

## Run locally

Open PowerShell in this folder (the folder containing `package.json`):

```powershell
npm install
npm run dev
```

Do **not** type `run install`, `npn run install`, or `npm install` from a parent folder that does not contain `package.json`.

The project root is the folder containing `package.json` and `index.html`.
